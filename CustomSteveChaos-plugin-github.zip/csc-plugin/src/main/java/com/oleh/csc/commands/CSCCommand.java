package com.oleh.csc.commands;

import com.oleh.csc.CSCPlugin;
import com.oleh.csc.arena.Arena;
import com.oleh.csc.classes.PlayerClass;
import com.oleh.csc.gui.ClassSelectGUI;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class CSCCommand implements CommandExecutor, TabCompleter {

    private final CSCPlugin plugin;

    public CSCCommand(CSCPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            sendHelp(sender);
            return true;
        }

        String sub = args[0].toLowerCase();
        switch (sub) {
            case "join" -> handleJoin(sender, args);
            case "leave" -> handleLeave(sender);
            case "class" -> handleClass(sender);
            case "balance", "bal" -> handleBalance(sender);
            case "lives" -> handleLives(sender);
            case "admin" -> handleAdmin(sender, args);
            default -> sendHelp(sender);
        }
        return true;
    }

    private void sendHelp(CommandSender sender) {
        sender.sendMessage("""
                §6§lCustom Steve Chaos
                §e/csc join <арена> §7- приєднатись до гри
                §e/csc leave §7- вийти з гри
                §e/csc class §7- обрати клас
                §e/csc balance §7- баланс золота
                §e/csc lives §7- скільки життів залишилось у грі
                §7Дуелі 1 на 1 відбуваються автоматично під час гри.
                §7Магазин і кузня прокачки — через сундуки на арені,
                §7команди для них немає.
                """);
        if (sender.hasPermission("csc.admin")) {
            sender.sendMessage("""
                    §c§lАдмін:
                    §c/csc admin create <арена>
                    §c/csc admin setlobby <арена>
                    §c/csc admin addmobspawn <арена>
                    §c/csc admin setbossspawn <арена>
                    §c/csc admin setduelspawn1 <арена>
                    §c/csc admin setduelspawn2 <арена>
                    §c/csc admin addshopchest <арена>
                    §c/csc admin addupgradechest <арена>
                    §c/csc admin setminplayers <арена> <число>
                    §c/csc admin setmaxplayers <арена> <число>
                    §c/csc admin reload
                    """);
        }
    }

    private Player playerOrNull(CommandSender sender) {
        if (sender instanceof Player p) return p;
        sender.sendMessage("§cЦю команду можна використати лише в грі.");
        return null;
    }

    private void handleJoin(CommandSender sender, String[] args) {
        Player player = playerOrNull(sender);
        if (player == null) return;
        String arenaName = args.length > 1 ? args[1] : "default";
        Arena arena = plugin.getArenaManager().get(arenaName);
        if (arena == null || !arena.isReady()) {
            player.sendMessage("§cАрена \"" + arenaName + "\" не знайдена або не налаштована.");
            return;
        }
        plugin.getGameManager().join(player, arena);
    }

    private void handleLeave(CommandSender sender) {
        Player player = playerOrNull(sender);
        if (player == null) return;
        if (!plugin.getGameManager().isInGame(player)) {
            player.sendMessage("§cТи не в грі.");
            return;
        }
        plugin.getGameManager().leave(player);
        player.sendMessage("§7Ти вийшов з гри.");
    }

    private void handleClass(CommandSender sender) {
        Player player = playerOrNull(sender);
        if (player == null) return;
        ClassSelectGUI.open(player);
    }

    private void handleBalance(CommandSender sender) {
        Player player = playerOrNull(sender);
        if (player == null) return;
        player.sendMessage("§6Твій баланс: §e" + (int) plugin.getEconomyManager().getBalance(player) + " золота");
    }

    private void handleLives(CommandSender sender) {
        Player player = playerOrNull(sender);
        if (player == null) return;
        if (!plugin.getGameManager().isInGame(player)) {
            player.sendMessage("§cТи не в грі.");
            return;
        }
        plugin.getGameManager().getGameOf(player).ifPresent(game ->
                player.sendMessage("§eЖиттів залишилось: §c" + game.getLives(player) + "§e/" + plugin.getCscConfig().getLivesPerPlayer()));
    }

    // ---- Admin / setup commands ----

    private void handleAdmin(CommandSender sender, String[] args) {
        if (!sender.hasPermission("csc.admin")) {
            sender.sendMessage("§cНемає прав.");
            return;
        }
        if (args.length < 2) {
            sendHelp(sender);
            return;
        }
        Player player = sender instanceof Player p ? p : null;
        String action = args[1].toLowerCase();

        if (action.equals("reload")) {
            plugin.reloadConfig();
            plugin.getArenaManager().loadAll();
            sender.sendMessage("§aКонфіг перезавантажено.");
            return;
        }

        if (args.length < 3) {
            sender.sendMessage("§cВкажи назву арени.");
            return;
        }
        String arenaName = args[2];
        Arena arena = plugin.getArenaManager().getOrCreate(arenaName);

        switch (action) {
            case "create" -> {
                plugin.getArenaManager().save(arena);
                sender.sendMessage("§aАрену \"" + arenaName + "\" створено. Тепер встанови lobby/mobspawn.");
            }
            case "setlobby" -> {
                if (player == null) { sender.sendMessage("§cЦю команду можна використати лише в грі (потрібна локація)."); return; }
                arena.setLobby(player.getLocation());
                plugin.getArenaManager().save(arena);
                sender.sendMessage("§aLobby для \"" + arenaName + "\" встановлено.");
            }
            case "addmobspawn" -> {
                if (player == null) { sender.sendMessage("§cЦю команду можна використати лише в грі (потрібна локація)."); return; }
                arena.addMobSpawnPoint(player.getLocation());
                plugin.getArenaManager().save(arena);
                sender.sendMessage("§aТочку спавну мобів додано (" + arena.getMobSpawnPoints().size() + " всього).");
            }
            case "setbossspawn" -> {
                if (player == null) { sender.sendMessage("§cЦю команду можна використати лише в грі (потрібна локація)."); return; }
                arena.setBossSpawnPoint(player.getLocation());
                plugin.getArenaManager().save(arena);
                sender.sendMessage("§aТочку спавну боса встановлено.");
            }
            case "setduelspawn1" -> {
                if (player == null) { sender.sendMessage("§cЦю команду можна використати лише в грі (потрібна локація)."); return; }
                arena.setDuelSpawn1(player.getLocation());
                plugin.getArenaManager().save(arena);
                sender.sendMessage("§aТочку дуелі №1 встановлено.");
            }
            case "setduelspawn2" -> {
                if (player == null) { sender.sendMessage("§cЦю команду можна використати лише в грі (потрібна локація)."); return; }
                arena.setDuelSpawn2(player.getLocation());
                plugin.getArenaManager().save(arena);
                sender.sendMessage("§aТочку дуелі №2 встановлено.");
            }
            case "addshopchest" -> {
                if (player == null) { sender.sendMessage("§cЦю команду можна використати лише в грі (потрібна локація)."); return; }
                player.getLocation().getBlock().setType(Material.CHEST);
                arena.addShopChestPoint(player.getLocation().getBlock().getLocation());
                plugin.getArenaManager().save(arena);
                sender.sendMessage("§aСундук поставлено і зареєстровано як магазин (" + arena.getShopChestPoints().size() + " всього).");
            }
            case "addupgradechest" -> {
                if (player == null) { sender.sendMessage("§cЦю команду можна використати лише в грі (потрібна локація)."); return; }
                player.getLocation().getBlock().setType(Material.CHEST);
                arena.addUpgradeChestPoint(player.getLocation().getBlock().getLocation());
                plugin.getArenaManager().save(arena);
                sender.sendMessage("§aСундук поставлено і зареєстровано як кузню прокачки (" + arena.getUpgradeChestPoints().size() + " всього).");
            }
            case "setminplayers" -> {
                if (args.length < 4) return;
                arena.setMinPlayers(Integer.parseInt(args[3]));
                plugin.getArenaManager().save(arena);
                sender.sendMessage("§aМінімум гравців: " + arena.getMinPlayers());
            }
            case "setmaxplayers" -> {
                if (args.length < 4) return;
                arena.setMaxPlayers(Integer.parseInt(args[3]));
                plugin.getArenaManager().save(arena);
                sender.sendMessage("§aМаксимум гравців: " + arena.getMaxPlayers());
            }
            default -> sendHelp(sender);
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> options = new ArrayList<>();
        if (args.length == 1) {
            options.addAll(Arrays.asList("join", "leave", "class", "balance", "lives"));
            if (sender.hasPermission("csc.admin")) options.add("admin");
        } else if (args.length == 2) {
            if (args[0].equalsIgnoreCase("join")) {
                options.addAll(plugin.getArenaManager().getAll().keySet());
            } else if (args[0].equalsIgnoreCase("admin")) {
                options.addAll(Arrays.asList("create", "setlobby", "addmobspawn", "setbossspawn",
                        "setduelspawn1", "setduelspawn2", "addshopchest", "addupgradechest",
                        "setminplayers", "setmaxplayers", "reload"));
            }
        } else if (args.length == 3 && args[0].equalsIgnoreCase("admin")) {
            options.addAll(plugin.getArenaManager().getAll().keySet());
        }
        String current = args[args.length - 1].toLowerCase();
        return options.stream().filter(o -> o.toLowerCase().startsWith(current)).collect(Collectors.toList());
    }
}
