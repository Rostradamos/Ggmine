package com.oleh.csc.util;

import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

/**
 * Captures a player's inventory/health/location/gamemode so it can be
 * restored after a minigame round or a duel ends.
 */
public class PlayerSnapshot {

    private final ItemStack[] inventory;
    private final ItemStack[] armor;
    private final Location location;
    private final GameMode gameMode;
    private final double health;
    private final double maxHealth;
    private final int foodLevel;

    private PlayerSnapshot(ItemStack[] inventory, ItemStack[] armor, Location location,
                            GameMode gameMode, double health, double maxHealth, int foodLevel) {
        this.inventory = inventory;
        this.armor = armor;
        this.location = location;
        this.gameMode = gameMode;
        this.health = health;
        this.maxHealth = maxHealth;
        this.foodLevel = foodLevel;
    }

    public static PlayerSnapshot capture(Player player) {
        return new PlayerSnapshot(
                player.getInventory().getContents().clone(),
                player.getInventory().getArmorContents().clone(),
                player.getLocation().clone(),
                player.getGameMode(),
                player.getHealth(),
                player.getAttribute(Attribute.GENERIC_MAX_HEALTH).getBaseValue(),
                player.getFoodLevel()
        );
    }

    public void restore(Player player) {
        player.getInventory().clear();
        player.getInventory().setContents(inventory);
        player.getInventory().setArmorContents(armor);
        var attr = player.getAttribute(Attribute.GENERIC_MAX_HEALTH);
        if (attr != null) attr.setBaseValue(maxHealth);
        player.setHealth(Math.min(health, maxHealth));
        player.setFoodLevel(foodLevel);
        player.setGameMode(gameMode);
        player.teleport(location);
    }
}
