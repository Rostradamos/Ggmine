package com.oleh.csc.items;

import org.bukkit.Material;

import java.util.List;

/**
 * The 8 "heavy items" from the original Custom Steve Chaos shop/wave-reward
 * list (Midas, the 3 upgrade books, Spikes, Rebirth, Jump, Shard). Prices
 * are taken from the CSC community guide; the per-stack increase for the
 * three books isn't published anywhere exact, so a reasonable value was
 * chosen — tweak {@code priceIncrement} below if you know the real one.
 *
 * {@code oneTime}: true for items you only ever need once (you keep using
 * the same physical item via its cooldown). false for the 3 books, which
 * stack — buying/picking them again increases the bonus and the price.
 */
public enum HeavyItem {

    MIDAS("Мідас", Material.GOLD_INGOT, 1250, 0, true,
            "§7Миттєво вбиває звичайного моба хвилі",
            "§7і дає §6+190 золота§7. Не діє на боса чи гравців.",
            "§eПКМ для використання §7(КД 45с)"),

    DAMAGE_BOOK("Книга Урону", Material.ENCHANTED_BOOK, 1550, 400, false,
            "§7+1 урону мечем, §7+0.5 урону луком.",
            "§7Ефект стакається з кожною книгою."),

    LIFE_BOOK("Книга Життя", Material.ENCHANTED_BOOK, 1400, 300, false,
            "§7+2 серця максимального здоров'я.",
            "§7Ефект стакається з кожною книгою."),

    REGEN_BOOK("Книга Регенерації", Material.ENCHANTED_BOOK, 1350, 300, false,
            "§7+0.5 хп/сек пасивної регенерації.",
            "§7Ефект стакається з кожною книгою."),

    SPIKES("Шипи", Material.CACTUS, 1800, 0, true,
            "§7Активуй: 6с блокуєш §b50%§7 урону",
            "§7і відбиваєш §b50%§7 назад атакеру.",
            "§eПКМ для використання §7(КД 30с)"),

    REBIRTH("Відродження", Material.TOTEM_OF_UNDYING, 7000, 0, true,
            "§7Одноразово: §a+1 життя§7 у поточній грі."),

    JUMP("Стрибок", Material.RABBIT_FOOT, 1250, 0, true,
            "§7Різкий стрибок вперед.",
            "§eПКМ для використання §7(КД 20с)"),

    SHARD("Осколок", Material.PRISMARINE_SHARD, 2400, 0, true,
            "§7Одноразово: розблоковує §dактивну здібність",
            "§7твого класу (інакше вона недоступна).");

    private final String displayName;
    private final Material icon;
    private final int basePrice;
    private final int priceIncrement;
    private final boolean oneTime;
    private final List<String> description;

    HeavyItem(String displayName, Material icon, int basePrice, int priceIncrement, boolean oneTime, String... description) {
        this.displayName = displayName;
        this.icon = icon;
        this.basePrice = basePrice;
        this.priceIncrement = priceIncrement;
        this.oneTime = oneTime;
        this.description = List.of(description);
    }

    public String getDisplayName() {
        return displayName;
    }

    public Material getIcon() {
        return icon;
    }

    public int getBasePrice() {
        return basePrice;
    }

    public int getPriceIncrement() {
        return priceIncrement;
    }

    public boolean isOneTime() {
        return oneTime;
    }

    public List<String> lore() {
        return description;
    }
}
