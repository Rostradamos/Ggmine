package com.oleh.csc.economy;

import com.oleh.csc.CSCPlugin;
import org.bukkit.OfflinePlayer;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Level;

/**
 * Simple per-player gold balance, backed by data/economy.yml. Gold is the
 * currency used by both the gacha shop and PvP duel betting.
 */
public class EconomyManager {

    private final CSCPlugin plugin;
    private final File file;
    private YamlConfiguration yaml;
    private final Map<UUID, Double> balances = new HashMap<>();

    public EconomyManager(CSCPlugin plugin) {
        this.plugin = plugin;
        File dataFolder = new File(plugin.getDataFolder(), "data");
        if (!dataFolder.exists()) dataFolder.mkdirs();
        this.file = new File(dataFolder, "economy.yml");
    }

    public void load() {
        yaml = YamlConfiguration.loadConfiguration(file);
        balances.clear();
        if (yaml.isConfigurationSection("balances")) {
            for (String key : yaml.getConfigurationSection("balances").getKeys(false)) {
                try {
                    balances.put(UUID.fromString(key), yaml.getDouble("balances." + key));
                } catch (IllegalArgumentException ignored) {
                }
            }
        }
    }

    public void save() {
        for (Map.Entry<UUID, Double> entry : balances.entrySet()) {
            yaml.set("balances." + entry.getKey(), entry.getValue());
        }
        try {
            yaml.save(file);
        } catch (IOException e) {
            plugin.getLogger().log(Level.WARNING, "Could not save economy.yml", e);
        }
    }

    public double getBalance(OfflinePlayer player) {
        return balances.getOrDefault(player.getUniqueId(), plugin.getCscConfig().getStartingGold());
    }

    public void deposit(Player player, double amount) {
        if (amount <= 0) return;
        balances.put(player.getUniqueId(), getBalance(player) + amount);
    }

    public boolean withdraw(Player player, double amount) {
        double balance = getBalance(player);
        if (balance < amount) return false;
        balances.put(player.getUniqueId(), balance - amount);
        return true;
    }

    public boolean has(Player player, double amount) {
        return getBalance(player) >= amount;
    }
}
