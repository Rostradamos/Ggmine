package com.oleh.csc.arena;

import com.oleh.csc.CSCPlugin;
import com.oleh.csc.util.LocationUtil;
import org.bukkit.Location;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Loads/saves arena definitions from config.yml under the "arenas" section
 * and provides the setup commands with a place to write into them.
 */
public class ArenaManager {

    private final CSCPlugin plugin;
    private final Map<String, Arena> arenas = new LinkedHashMap<>();

    public ArenaManager(CSCPlugin plugin) {
        this.plugin = plugin;
    }

    public void loadAll() {
        arenas.clear();
        FileConfiguration cfg = plugin.getConfig();
        ConfigurationSection arenasSection = cfg.getConfigurationSection("arenas");
        if (arenasSection == null) return;
        for (String name : arenasSection.getKeys(false)) {
            ConfigurationSection s = arenasSection.getConfigurationSection(name);
            Arena arena = new Arena(name);
            arena.setLobby(LocationUtil.load(s, "lobby"));
            arena.setBossSpawnPoint(LocationUtil.load(s, "boss-spawn"));
            arena.setDuelSpawn1(LocationUtil.load(s, "duel-spawn-1"));
            arena.setDuelSpawn2(LocationUtil.load(s, "duel-spawn-2"));
            arena.setMinPlayers(s.getInt("min-players", 1));
            arena.setMaxPlayers(s.getInt("max-players", 8));
            ConfigurationSection mobSpawns = s.getConfigurationSection("mob-spawns");
            if (mobSpawns != null) {
                for (String key : mobSpawns.getKeys(false)) {
                    Location loc = LocationUtil.load(mobSpawns, key);
                    if (loc != null) arena.addMobSpawnPoint(loc);
                }
            }
            ConfigurationSection shopChests = s.getConfigurationSection("shop-chests");
            if (shopChests != null) {
                for (String key : shopChests.getKeys(false)) {
                    Location loc = LocationUtil.load(shopChests, key);
                    if (loc != null) arena.addShopChestPoint(loc);
                }
            }
            ConfigurationSection upgradeChests = s.getConfigurationSection("upgrade-chests");
            if (upgradeChests != null) {
                for (String key : upgradeChests.getKeys(false)) {
                    Location loc = LocationUtil.load(upgradeChests, key);
                    if (loc != null) arena.addUpgradeChestPoint(loc);
                }
            }
            arenas.put(name.toLowerCase(), arena);
        }
    }

    public void save(Arena arena) {
        String path = "arenas." + arena.getName();
        FileConfiguration cfg = plugin.getConfig();
        cfg.set(path + ".min-players", arena.getMinPlayers());
        cfg.set(path + ".max-players", arena.getMaxPlayers());
        LocationUtil.save(cfg, path + ".lobby", arena.getLobby());
        LocationUtil.save(cfg, path + ".boss-spawn", arena.getBossSpawnPoint());
        LocationUtil.save(cfg, path + ".duel-spawn-1", arena.getDuelSpawn1());
        LocationUtil.save(cfg, path + ".duel-spawn-2", arena.getDuelSpawn2());
        for (int i = 0; i < arena.getMobSpawnPoints().size(); i++) {
            LocationUtil.save(cfg, path + ".mob-spawns.point-" + i, arena.getMobSpawnPoints().get(i));
        }
        for (int i = 0; i < arena.getShopChestPoints().size(); i++) {
            LocationUtil.save(cfg, path + ".shop-chests.point-" + i, arena.getShopChestPoints().get(i));
        }
        for (int i = 0; i < arena.getUpgradeChestPoints().size(); i++) {
            LocationUtil.save(cfg, path + ".upgrade-chests.point-" + i, arena.getUpgradeChestPoints().get(i));
        }
        plugin.saveConfig();
    }

    public Arena getOrCreate(String name) {
        return arenas.computeIfAbsent(name.toLowerCase(), n -> new Arena(name));
    }

    public Arena get(String name) {
        return arenas.get(name.toLowerCase());
    }

    public Map<String, Arena> getAll() {
        return arenas;
    }
}
