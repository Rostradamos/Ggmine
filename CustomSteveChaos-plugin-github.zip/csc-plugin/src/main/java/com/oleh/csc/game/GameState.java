package com.oleh.csc.game;

public enum GameState {
    WAITING,
    STARTING,
    INGAME,
    ENDING
}
