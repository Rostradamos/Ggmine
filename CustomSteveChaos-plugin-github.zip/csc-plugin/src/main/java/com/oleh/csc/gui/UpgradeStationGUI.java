package com.oleh.csc.gui;

import com.oleh.csc.CSCPlugin;
import com.oleh.csc.items.UpgradeableEnchant;
import com.oleh.csc.util.ItemBuilder;
import com.oleh.csc.util.Keys;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.List;

/**
 * The "forge" chest GUI: place any sword/bow/armor piece in the center
 * slot and pay gold to level up whatever enchant it can take - its base
 * enchant for that gear category (Sharpness/Power/Protection), plus any
 * bonus enchant (Bane of Arthropods/Fire Aspect/Thorns) it already has.
 * Reached only by right-clicking a chest the admin registered with
 * {@code /csc admin addupgradechest} - there is no player-facing command.
 */
public class UpgradeStationGUI {

    public static final int INPUT_SLOT = 13;
    private static final int[] BUTTON_SLOTS = {10, 11, 12, 14, 15, 16};

    public static void open(CSCPlugin plugin, Player player) {
        CSCMenuHolder holder = new CSCMenuHolder(CSCMenuHolder.MenuType.UPGRADE);
        Inventory inv = Bukkit.createInventory(holder, 27, "§8Кузня — поклади предмет у центр");
        holder.setInventory(inv);

        inv.setItem(22, new ItemBuilder(Material.BARRIER)
                .name("§cЗакрити")
                .tag(Keys.MENU_CLOSE_BUTTON, PersistentDataType.BYTE, (byte) 1)
                .build());

        refresh(plugin, inv);
        player.openInventory(inv);
    }

    /** Rebuilds the upgrade-button slots from whatever is currently sitting in the input slot. */
    public static void refresh(CSCPlugin plugin, Inventory inv) {
        for (int slot : BUTTON_SLOTS) {
            inv.setItem(slot, filler());
        }

        ItemStack item = inv.getItem(INPUT_SLOT);
        if (item == null) return;

        List<UpgradeableEnchant> options = plugin.getUpgradeManager().availableUpgrades(item);
        for (int i = 0; i < options.size() && i < BUTTON_SLOTS.length; i++) {
            UpgradeableEnchant ue = options.get(i);
            int current = plugin.getUpgradeManager().currentLevel(item, ue);
            int next = current + 1;

            List<String> lore = new ArrayList<>();
            ItemStack button;
            if (next > ue.getMaxLevel()) {
                lore.add("§7Поточний рівень: §f" + current);
                lore.add("§7Досягнуто максимум.");
                button = new ItemBuilder(Material.BARRIER)
                        .name("§c" + ue.getDisplayName() + " (МАКС)")
                        .lore(lore)
                        .build();
            } else {
                int price = ue.priceFor(next);
                lore.add("§7Рівень: §f" + current + " §7→ §f" + next);
                lore.add("§6Ціна: §e" + price + " золота");
                lore.add("§aКлікни, щоб прокачати");
                button = new ItemBuilder(Material.ENCHANTED_BOOK)
                        .name("§b" + ue.getDisplayName())
                        .lore(lore)
                        .tag(Keys.UPGRADE_BUTTON, PersistentDataType.STRING, ue.name())
                        .build();
            }
            inv.setItem(BUTTON_SLOTS[i], button);
        }
    }

    private static ItemStack filler() {
        return new ItemBuilder(Material.GRAY_STAINED_GLASS_PANE).name(" ").build();
    }
}
