package com.oleh.csc.gui;

import com.oleh.csc.CSCPlugin;
import com.oleh.csc.items.HeavyItem;
import com.oleh.csc.util.ItemBuilder;
import com.oleh.csc.util.Keys;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.List;

/**
 * The paid version of the same 8 heavy items (buy anytime with gold,
 * instead of waiting for the free wave-end offer). Already-owned
 * one-time items show as owned instead of a price.
 */
public class ShopGUI {

    private static final int[] SLOTS = {10, 11, 12, 13, 14, 15, 16, 17};

    public static void open(CSCPlugin plugin, Player player) {
        CSCMenuHolder holder = new CSCMenuHolder(CSCMenuHolder.MenuType.SHOP);
        Inventory inv = Bukkit.createInventory(holder, 27, "§8Магазин CSC — Важкі предмети");
        holder.setInventory(inv);

        double balance = plugin.getEconomyManager().getBalance(player);
        HeavyItem[] items = HeavyItem.values();

        for (int i = 0; i < items.length && i < SLOTS.length; i++) {
            HeavyItem item = items[i];
            boolean owned = item.isOneTime() && plugin.getHeavyItemManager().hasOneTime(player, item);

            List<String> lore = new ArrayList<>(item.lore());
            lore.add("");
            if (owned) {
                lore.add("§7Вже отримано");
            } else {
                int price = plugin.getHeavyItemManager().currentPrice(player, item);
                lore.add("§7Ціна: §6" + price + " золота");
                lore.add(balance >= price ? "§aКлікни, щоб купити" : "§cНедостатньо золота");
            }

            ItemStack display = new ItemBuilder(owned ? Material.GRAY_DYE : item.getIcon())
                    .name((owned ? "§7" : "§e§l") + item.getDisplayName())
                    .lore(lore)
                    .tag(Keys.SHOP_BUY_ITEM, PersistentDataType.STRING, item.name())
                    .build();
            inv.setItem(SLOTS[i], display);
        }

        inv.setItem(22, new ItemBuilder(Material.BARRIER)
                .name("§cЗакрити")
                .tag(Keys.MENU_CLOSE_BUTTON, PersistentDataType.BYTE, (byte) 1)
                .build());

        player.openInventory(inv);
    }
}
