package com.oleh.csc.gui;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

import java.util.List;
import java.util.Map;

/**
 * Marker holder so the inventory-click listener can tell which custom
 * menu a clicked inventory belongs to without parsing titles.
 */
public class CSCMenuHolder implements InventoryHolder {

    public enum MenuType {
        CLASS_SELECT,
        SHOP,
        DROP_CHOICE,
        UPGRADE
    }

    private final MenuType type;
    private Inventory inventory;
    private Map<Integer, List<ItemStack>> rewardStacks;

    public CSCMenuHolder(MenuType type) {
        this.type = type;
    }

    public MenuType getType() {
        return type;
    }

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    /**
     * DROP_CHOICE only: the exact (already-rolled) item stack(s) each offer
     * slot grants, keyed by slot index - so a re-render (or the click
     * handler reading it back) never re-rolls a sword/armor's random
     * bonus enchant differently from what the player saw in the GUI.
     */
    public void setRewardStacks(Map<Integer, List<ItemStack>> rewardStacks) {
        this.rewardStacks = rewardStacks;
    }

    public Map<Integer, List<ItemStack>> getRewardStacks() {
        return rewardStacks;
    }
}
