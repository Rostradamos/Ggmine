package com.oleh.csc.listeners;

import com.oleh.csc.CSCPlugin;
import com.oleh.csc.classes.PlayerClass;
import com.oleh.csc.gui.CSCMenuHolder;
import com.oleh.csc.gui.ShopGUI;
import com.oleh.csc.gui.UpgradeStationGUI;
import com.oleh.csc.items.HeavyItem;
import com.oleh.csc.items.UpgradeableEnchant;
import com.oleh.csc.items.WaveRewardItem;
import com.oleh.csc.util.Keys;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.List;

public class GUIListener implements Listener {

    private final CSCPlugin plugin;

    public GUIListener(CSCPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getInventory().getHolder() instanceof CSCMenuHolder holder)) return;
        if (!(event.getWhoClicked() instanceof Player player)) return;

        if (holder.getType() == CSCMenuHolder.MenuType.UPGRADE) {
            handleUpgradeClick(event, player);
            return;
        }

        event.setCancelled(true);

        ItemStack clicked = event.getCurrentItem();
        if (clicked == null || clicked.getItemMeta() == null) return;
        ItemMeta meta = clicked.getItemMeta();

        switch (holder.getType()) {
            case CLASS_SELECT -> {
                String className = meta.getPersistentDataContainer().get(Keys.CLASS_SELECT_ITEM, PersistentDataType.STRING);
                if (className == null) return;
                try {
                    PlayerClass clazz = PlayerClass.valueOf(className);
                    plugin.getClassManager().select(player, clazz);
                    player.sendMessage("§aОбрано клас: §e" + clazz.getDisplayName());
                    player.closeInventory();
                    if (plugin.getGameManager().isInGame(player)) {
                        plugin.getGameManager().getGameOf(player).ifPresent(game -> {
                            if (game.getState() == com.oleh.csc.game.GameState.INGAME) {
                                plugin.getClassManager().applyKit(player);
                            }
                        });
                    }
                } catch (IllegalArgumentException ignored) {
                }
            }
            case SHOP -> {
                if (meta.getPersistentDataContainer().has(Keys.MENU_CLOSE_BUTTON, PersistentDataType.BYTE)) {
                    player.closeInventory();
                    return;
                }
                String itemName = meta.getPersistentDataContainer().get(Keys.SHOP_BUY_ITEM, PersistentDataType.STRING);
                if (itemName == null) return;
                try {
                    HeavyItem item = HeavyItem.valueOf(itemName);
                    if (plugin.getHeavyItemManager().purchase(player, item)) {
                        player.closeInventory();
                    } else {
                        ShopGUI.open(plugin, player); // refresh (e.g. price/owned state)
                    }
                } catch (IllegalArgumentException ignored) {
                }
            }
            case DROP_CHOICE -> {
                String itemName = meta.getPersistentDataContainer().get(Keys.WAVE_REWARD_CHOICE, PersistentDataType.STRING);
                if (itemName == null) return;
                List<ItemStack> stacks = holder.getRewardStacks() != null
                        ? holder.getRewardStacks().get(event.getRawSlot())
                        : null;
                if (stacks == null) return;

                for (ItemStack stack : stacks) {
                    player.getInventory().addItem(stack.clone()).values()
                            .forEach(leftover -> player.getWorld().dropItemNaturally(player.getLocation(), leftover));
                }
                try {
                    player.sendMessage("§aОтримано: §f" + WaveRewardItem.valueOf(itemName).getDisplayName());
                } catch (IllegalArgumentException ignored) {
                }
                player.closeInventory();
            }
            default -> {
            }
        }
    }

    /**
     * The Upgrade Station's input slot (center) must behave like a normal,
     * placeable inventory slot so the player can physically drop their
     * gear in and take it back out; every other slot in that GUI is a
     * decorative/clickable button and always gets cancelled.
     */
    private void handleUpgradeClick(InventoryClickEvent event, Player player) {
        if (event.getRawSlot() == UpgradeStationGUI.INPUT_SLOT) {
            // The item hasn't actually moved into/out of the slot yet at this point in the event -
            // refresh the buttons one tick later once the default click behaviour has applied.
            Bukkit.getScheduler().runTask(plugin, () -> UpgradeStationGUI.refresh(plugin, event.getInventory()));
            return;
        }

        event.setCancelled(true);
        ItemStack clicked = event.getCurrentItem();
        if (clicked == null || clicked.getItemMeta() == null) return;
        ItemMeta meta = clicked.getItemMeta();

        if (meta.getPersistentDataContainer().has(Keys.MENU_CLOSE_BUTTON, PersistentDataType.BYTE)) {
            player.closeInventory();
            return;
        }

        String enchantName = meta.getPersistentDataContainer().get(Keys.UPGRADE_BUTTON, PersistentDataType.STRING);
        if (enchantName == null) return;
        try {
            UpgradeableEnchant ue = UpgradeableEnchant.valueOf(enchantName);
            ItemStack target = event.getInventory().getItem(UpgradeStationGUI.INPUT_SLOT);
            if (target == null) return;
            if (plugin.getUpgradeManager().upgrade(player, target, ue)) {
                event.getInventory().setItem(UpgradeStationGUI.INPUT_SLOT, target);
            }
            UpgradeStationGUI.refresh(plugin, event.getInventory());
        } catch (IllegalArgumentException ignored) {
        }
    }

    /** None of our custom menus support multi-slot dragging - keep it to single clicks only. */
    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        if (event.getInventory().getHolder() instanceof CSCMenuHolder) {
            event.setCancelled(true);
        }
    }

    /** The Upgrade Station's input slot can hold a real item - make sure it's never silently lost when the GUI closes. */
    @EventHandler
    public void onClose(InventoryCloseEvent event) {
        if (!(event.getInventory().getHolder() instanceof CSCMenuHolder holder)) return;
        if (holder.getType() != CSCMenuHolder.MenuType.UPGRADE) return;
        if (!(event.getPlayer() instanceof Player player)) return;

        ItemStack leftover = event.getInventory().getItem(UpgradeStationGUI.INPUT_SLOT);
        if (leftover != null) {
            event.getInventory().setItem(UpgradeStationGUI.INPUT_SLOT, null);
            player.getInventory().addItem(leftover).values()
                    .forEach(it -> player.getWorld().dropItemNaturally(player.getLocation(), it));
        }
    }
}
