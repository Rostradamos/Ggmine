package com.oleh.csc.listeners;

import com.oleh.csc.CSCPlugin;
import com.oleh.csc.game.Game;
import com.oleh.csc.game.WaveManager;
import com.oleh.csc.items.HeavyItem;
import com.oleh.csc.util.Keys;
import com.oleh.csc.util.Text;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.projectiles.ProjectileSource;

/**
 * Handles all combat-related rules: class/utility item activation, class +
 * heavy-item damage modifiers, duel/PvP gating, wave-mob kill rewards, and
 * intercepting lethal damage so players never actually "die" (no drops,
 * no respawn screen) — instead they lose a life and respawn, get fully
 * eliminated, or lose an automatic duel.
 */
public class CombatListener implements Listener {

    private final CSCPlugin plugin;

    public CombatListener(CSCPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent event) {
        if (event.getHand() != org.bukkit.inventory.EquipmentSlot.HAND) return;
        if (event.getAction() != org.bukkit.event.block.Action.RIGHT_CLICK_AIR
                && event.getAction() != org.bukkit.event.block.Action.RIGHT_CLICK_BLOCK) return;

        ItemStack item = event.getItem();
        if (item == null) return;
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return;

        Player player = event.getPlayer();
        if (!plugin.getGameManager().isInGame(player)) return;

        String abilityClass = meta.getPersistentDataContainer().get(Keys.ABILITY_ITEM, PersistentDataType.STRING);
        if (abilityClass != null) {
            plugin.getClassManager().useAbility(player);
            event.setCancelled(true);
            return;
        }

        String utilityItem = meta.getPersistentDataContainer().get(Keys.UTILITY_ITEM, PersistentDataType.STRING);
        if (utilityItem != null) {
            try {
                plugin.getHeavyItemManager().useUtility(player, HeavyItem.valueOf(utilityItem));
            } catch (IllegalArgumentException ignored) {
            }
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.NORMAL, ignoreCancelled = true)
    public void onDamageByEntity(EntityDamageByEntityEvent event) {
        // --- PvP gating: only allow player-vs-player damage inside an active auto-duel ---
        if (event.getEntity() instanceof Player victim) {
            Player pvpAttacker = resolvePlayerAttacker(event.getDamager());
            if (pvpAttacker != null) {
                boolean sameDuel = plugin.getAutoDuelManager().isDueling(victim)
                        && plugin.getAutoDuelManager().areOpponents(victim, pvpAttacker);
                if (!sameDuel) {
                    event.setCancelled(true);
                }
                return; // either let duel damage through unmodified, or it was just cancelled above
            }
        }

        // --- A wave mob/boss hitting a player: apply Spikes block + reflect ---
        if (event.getEntity() instanceof Player victim && event.getDamager() instanceof LivingEntity mob
                && mob.getPersistentDataContainer().has(Keys.IS_WAVE_MOB, PersistentDataType.STRING)) {
            if (plugin.getHeavyItemManager().isSpikesActive(victim)) {
                double original = event.getDamage();
                event.setDamage(original * 0.5);
                mob.damage(original * 0.5, victim);
            }
            return;
        }

        // --- Player (melee or projectile) damaging a wave mob/boss: apply class + heavy-item bonuses ---
        Player attacker = resolvePlayerAttacker(event.getDamager());
        if (attacker != null && event.getEntity() instanceof LivingEntity victim) {
            boolean isWaveMob = victim.getPersistentDataContainer().has(Keys.IS_WAVE_MOB, PersistentDataType.STRING);
            if (!isWaveMob) return;

            boolean melee = event.getDamager() instanceof Player;
            double classMultiplier = plugin.getClassManager().passiveDamageMultiplier(attacker);
            double heavyBonus = melee
                    ? plugin.getHeavyItemManager().getMeleeDamageBonus(attacker)
                    : plugin.getHeavyItemManager().getRangedDamageBonus(attacker);

            double finalDamage = event.getDamage() * classMultiplier + heavyBonus;
            event.setDamage(finalDamage);
            plugin.getClassManager().applyVampireLifesteal(attacker, finalDamage);
        }
    }

    /** Resolves the Player responsible for a damage source, whether it's a direct hit or a fired projectile. */
    private Player resolvePlayerAttacker(org.bukkit.entity.Entity damager) {
        if (damager instanceof Player player) return player;
        if (damager instanceof Projectile projectile) {
            ProjectileSource source = projectile.getShooter();
            if (source instanceof Player player) return player;
        }
        return null;
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;

        boolean inGame = plugin.getGameManager().isInGame(player);
        boolean inDuel = plugin.getAutoDuelManager().isDueling(player);
        if (!inGame && !inDuel) return;

        if (event.getFinalDamage() >= player.getHealth()) {
            event.setCancelled(true);
            player.setHealth(1.0);
            player.setFireTicks(0);

            if (inDuel) {
                plugin.getAutoDuelManager().handleDuelLoss(player);
            } else {
                plugin.getGameManager().getGameOf(player).ifPresent(game -> game.onPlayerDown(player));
            }
        }
    }

    @EventHandler
    public void onEntityDeath(EntityDeathEvent event) {
        LivingEntity entity = event.getEntity();
        String arenaName = entity.getPersistentDataContainer().get(Keys.IS_WAVE_MOB, PersistentDataType.STRING);
        if (arenaName == null) return;

        boolean isBoss = entity.getPersistentDataContainer().has(Keys.IS_BOSS, PersistentDataType.STRING);
        if (isBoss) {
            WaveManager.cancelBossTask(entity.getUniqueId());
        }

        event.getDrops().clear();
        event.setDroppedExp(0);

        Game game = plugin.getGameManager().findByArenaMobTag(arenaName);
        if (game != null) {
            game.onMobDeath(entity.getUniqueId());
        }

        if (entity.getKiller() instanceof Player killer) {
            int reward = isBoss ? plugin.getCscConfig().getGoldPerBossKill() : plugin.getCscConfig().getGoldPerKill();
            plugin.getEconomyManager().deposit(killer, reward);
            killer.sendActionBar(Text.legacy("§6+" + reward + " золота"));
        }
    }
}
