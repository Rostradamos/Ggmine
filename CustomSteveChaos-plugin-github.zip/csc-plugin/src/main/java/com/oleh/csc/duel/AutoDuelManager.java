package com.oleh.csc.duel;

import com.oleh.csc.CSCPlugin;
import com.oleh.csc.arena.Arena;
import com.oleh.csc.game.Game;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

/**
 * Automatic, solo-mode PvP duels embedded in the PvE round (matching how
 * the original Custom Steve Chaos mixes duels into wave survival). After
 * the configured wave, every time a wave is cleared two random alive,
 * not-already-dueling players are teleported to the arena's duel spawns
 * and fight with their current kit/health. There's no betting here (v1
 * simplification) — the winner just gets a flat gold reward and both
 * players return to where they were in the arena afterwards; losing a
 * duel does NOT cost the loser one of their PvE lives.
 */
public class AutoDuelManager {

    private record ActiveDuel(UUID player1, UUID player2, Game game) {
    }

    private final CSCPlugin plugin;
    private final Map<UUID, ActiveDuel> activeDuels = new HashMap<>();
    private final Map<UUID, Location> returnLocations = new HashMap<>();
    private final Random random = new Random();

    public AutoDuelManager(CSCPlugin plugin) {
        this.plugin = plugin;
    }

    public boolean isDueling(Player player) {
        return activeDuels.containsKey(player.getUniqueId());
    }

    public boolean areOpponents(Player a, Player b) {
        ActiveDuel duel = activeDuels.get(a.getUniqueId());
        if (duel == null) return false;
        UUID other = duel.player1().equals(a.getUniqueId()) ? duel.player2() : duel.player1();
        return other.equals(b.getUniqueId());
    }

    /** Called by Game right after a wave is cleared. No-op if the arena has no duel spawns configured, or too few eligible players. */
    public void maybeStartDuel(Game game) {
        Arena arena = game.getArena();
        if (!arena.isDuelReady()) return;

        List<UUID> eligible = new ArrayList<>();
        for (UUID id : game.getAlivePlayers()) {
            if (!activeDuels.containsKey(id)) eligible.add(id);
        }
        if (eligible.size() < 2) return;

        Collections.shuffle(eligible, random);
        Player p1 = Bukkit.getPlayer(eligible.get(0));
        Player p2 = Bukkit.getPlayer(eligible.get(1));
        if (p1 == null || p2 == null) return;

        startDuel(game, p1, p2);
    }

    private void startDuel(Game game, Player p1, Player p2) {
        ActiveDuel duel = new ActiveDuel(p1.getUniqueId(), p2.getUniqueId(), game);
        activeDuels.put(p1.getUniqueId(), duel);
        activeDuels.put(p2.getUniqueId(), duel);

        returnLocations.put(p1.getUniqueId(), p1.getLocation().clone());
        returnLocations.put(p2.getUniqueId(), p2.getLocation().clone());

        healFully(p1);
        healFully(p2);

        Arena arena = game.getArena();
        p1.teleport(arena.getDuelSpawn1());
        p2.teleport(arena.getDuelSpawn2());

        game.broadcast("§c⚔ Автоматична дуель: §f" + p1.getName() + " §7проти §f" + p2.getName()
                + "§7! Переможець отримає §6" + plugin.getCscConfig().getDuelWinReward() + " золота§7.");
    }

    private void healFully(Player player) {
        var attr = player.getAttribute(Attribute.GENERIC_MAX_HEALTH);
        if (attr != null) player.setHealth(attr.getValue());
    }

    /** Called from CombatListener when a dueling player takes what would be a lethal hit. */
    public void handleDuelLoss(Player loser) {
        ActiveDuel duel = activeDuels.get(loser.getUniqueId());
        if (duel == null) return;
        UUID winnerId = duel.player1().equals(loser.getUniqueId()) ? duel.player2() : duel.player1();
        finishDuel(duel, winnerId, loser.getUniqueId());
    }

    /** Called when a dueling player disconnects or leaves the game mid-duel — counts as an automatic loss. */
    public void forfeit(Player leaving) {
        if (activeDuels.containsKey(leaving.getUniqueId())) {
            handleDuelLoss(leaving);
        }
    }

    private void finishDuel(ActiveDuel duel, UUID winnerId, UUID loserId) {
        activeDuels.remove(duel.player1());
        activeDuels.remove(duel.player2());

        Player winner = Bukkit.getPlayer(winnerId);
        Player loser = Bukkit.getPlayer(loserId);
        int reward = plugin.getCscConfig().getDuelWinReward();

        if (winner != null) {
            plugin.getEconomyManager().deposit(winner, reward);
            duel.game().broadcast("§6⚔ " + winner.getName() + " §eвиграв дуель і отримав §6" + reward + " золота§e!");
            healFully(winner);
            restoreLocation(winner);
        }
        if (loser != null) {
            healFully(loser);
            restoreLocation(loser);
        }
    }

    private void restoreLocation(Player player) {
        Location loc = returnLocations.remove(player.getUniqueId());
        if (loc != null) player.teleport(loc);
    }
}
