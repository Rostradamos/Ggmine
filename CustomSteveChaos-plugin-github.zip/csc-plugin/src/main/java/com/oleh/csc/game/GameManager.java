package com.oleh.csc.game;

import com.oleh.csc.CSCPlugin;
import com.oleh.csc.arena.Arena;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

/**
 * Owns one {@link Game} per configured arena and tracks which arena each
 * in-game player currently belongs to.
 */
public class GameManager {

    private final CSCPlugin plugin;
    private final Map<String, Game> games = new HashMap<>();
    private final Map<UUID, String> playerArena = new HashMap<>();

    public GameManager(CSCPlugin plugin) {
        this.plugin = plugin;
    }

    public Game getOrCreate(Arena arena) {
        return games.computeIfAbsent(arena.getName().toLowerCase(), n -> new Game(plugin, arena));
    }

    public Game get(String arenaName) {
        return games.get(arenaName.toLowerCase());
    }

    public Optional<Game> getGameOf(Player player) {
        String arena = playerArena.get(player.getUniqueId());
        if (arena == null) return Optional.empty();
        Game game = games.get(arena);
        // Self-heal: a round that ended on its own (endGame()) clears the Game's internal
        // player set without going through leave(), so this mapping can go stale.
        if (game == null || !game.getPlayers().contains(player.getUniqueId())) {
            playerArena.remove(player.getUniqueId());
            return Optional.empty();
        }
        return Optional.of(game);
    }

    public boolean isInGame(Player player) {
        return getGameOf(player).isPresent();
    }

    public boolean join(Player player, Arena arena) {
        if (isInGame(player)) {
            player.sendMessage("§cТи вже в грі. Напиши /csc leave.");
            return false;
        }
        Game game = getOrCreate(arena);
        if (game.join(player)) {
            playerArena.put(player.getUniqueId(), arena.getName().toLowerCase());
            return true;
        }
        return false;
    }

    public void leave(Player player) {
        String arenaName = playerArena.remove(player.getUniqueId());
        if (arenaName == null) return;
        Game game = games.get(arenaName);
        if (game != null) game.leave(player);
    }

    public Game findByArenaMobTag(String arenaName) {
        return games.get(arenaName.toLowerCase());
    }
}
