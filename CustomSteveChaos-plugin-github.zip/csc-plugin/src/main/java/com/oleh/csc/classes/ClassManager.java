package com.oleh.csc.classes;

import com.oleh.csc.CSCPlugin;
import com.oleh.csc.util.ItemBuilder;
import com.oleh.csc.util.Keys;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.SmallFireball;
import org.bukkit.entity.ThrownPotion;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Tracks which class each in-game player has chosen, hands out the
 * class kit, and runs active-ability logic + passive hooks.
 */
public class ClassManager {

    private final CSCPlugin plugin;
    private final Map<UUID, PlayerClass> selected = new HashMap<>();
    private final Map<UUID, Long> cooldowns = new HashMap<>();
    private final Set<UUID> shardUnlocked = new HashSet<>();

    public ClassManager(CSCPlugin plugin) {
        this.plugin = plugin;
    }

    public void select(Player player, PlayerClass clazz) {
        selected.put(player.getUniqueId(), clazz);
    }

    public PlayerClass get(Player player) {
        return selected.getOrDefault(player.getUniqueId(), PlayerClass.WARRIOR);
    }

    public boolean hasSelected(Player player) {
        return selected.containsKey(player.getUniqueId());
    }

    public void clear(Player player) {
        selected.remove(player.getUniqueId());
        cooldowns.remove(player.getUniqueId());
        shardUnlocked.remove(player.getUniqueId());
    }

    /** Called by HeavyItemManager when the player obtains a "Shard" — this is what actually turns on their active ability. */
    public void unlockShard(Player player) {
        shardUnlocked.add(player.getUniqueId());
        giveAbilityItemIfMissing(player);
    }

    public boolean hasShardUnlocked(Player player) {
        return shardUnlocked.contains(player.getUniqueId());
    }

    private void giveAbilityItemIfMissing(Player player) {
        ItemStack item = abilityItem(get(player));
        if (player.getInventory().getItem(8) == null) {
            player.getInventory().setItem(8, item);
        } else {
            player.getInventory().addItem(item);
        }
    }

    /** Applies max-health attribute and gives the starter kit for the player's class. */
    public void applyKit(Player player) {
        PlayerClass clazz = get(player);
        player.getInventory().clear();
        player.getInventory().setArmorContents(null);

        var healthAttr = player.getAttribute(Attribute.GENERIC_MAX_HEALTH);
        if (healthAttr != null) {
            healthAttr.setBaseValue(clazz.getMaxHealth() * 0.5 * 2); // maxHealth stored as half-hearts -> hp points
        }
        player.setHealth(player.getAttribute(Attribute.GENERIC_MAX_HEALTH).getValue());
        player.setFoodLevel(20);

        PlayerInventory inv = player.getInventory();
        switch (clazz) {
            case WARRIOR -> {
                inv.addItem(new ItemBuilder(Material.IRON_SWORD).name("§fМеч воїна").hideFlags().build());
                inv.setArmorContents(leatherSet());
            }
            case ARCHER -> {
                // All bows this plugin hands out are permanently enchanted with Infinity - see WaveRewardItem too.
                inv.addItem(new ItemBuilder(Material.BOW).name("§fЛук лучника")
                        .enchant(Enchantment.INFINITY, 1).hideFlags().build());
                inv.addItem(new ItemStack(Material.ARROW, 64));
                inv.setArmorContents(leatherSet());
            }
            case ALCHEMIST -> {
                inv.addItem(new ItemBuilder(Material.WOODEN_SWORD).name("§fНіж алхіміка").hideFlags().build());
                inv.setArmorContents(leatherSet());
            }
            case VAMPIRE -> {
                inv.addItem(new ItemBuilder(Material.STONE_SWORD).name("§fКоготь вампіра").hideFlags().build());
                inv.setArmorContents(leatherSet());
            }
            case MAGE -> {
                inv.addItem(new ItemBuilder(Material.BLAZE_ROD).name("§fПосох мага").hideFlags().build());
                inv.setArmorContents(leatherSet());
            }
            case TANK -> {
                inv.addItem(new ItemBuilder(Material.STONE_SWORD).name("§fКийок громила").hideFlags().build());
                inv.setArmorContents(ironSet());
            }
        }

        var kbAttr = player.getAttribute(Attribute.GENERIC_KNOCKBACK_RESISTANCE);
        if (kbAttr != null) {
            kbAttr.setBaseValue(clazz == PlayerClass.TANK ? 0.6 : 0.0);
        }

        // Active ability is only usable once the player has picked up a "Shard" heavy item -
        // see HeavyItem.SHARD / ClassManager#unlockShard.
        if (hasShardUnlocked(player)) {
            inv.setItem(8, abilityItem(clazz));
        }
    }

    private ItemStack[] leatherSet() {
        return new ItemStack[]{
                new ItemBuilder(Material.LEATHER_BOOTS).hideFlags().build(),
                new ItemBuilder(Material.LEATHER_LEGGINGS).hideFlags().build(),
                new ItemBuilder(Material.LEATHER_CHESTPLATE).hideFlags().build(),
                new ItemBuilder(Material.LEATHER_HELMET).hideFlags().build()
        };
    }

    private ItemStack[] ironSet() {
        return new ItemStack[]{
                new ItemBuilder(Material.IRON_BOOTS).hideFlags().build(),
                new ItemBuilder(Material.IRON_LEGGINGS).hideFlags().build(),
                new ItemBuilder(Material.IRON_CHESTPLATE).hideFlags().build(),
                new ItemBuilder(Material.IRON_HELMET).hideFlags().build()
        };
    }

    private ItemStack abilityItem(PlayerClass clazz) {
        return new ItemBuilder(Material.NETHER_STAR)
                .name("§d✦ " + clazz.getActiveDescription().split("—")[0].replace("Актив:", "").trim())
                .lore(clazz.getActiveDescription(), "§7ПКМ, щоб використати", "§7Відновлення: " + clazz.getAbilityCooldownSeconds() + "с")
                .tag(Keys.ABILITY_ITEM, PersistentDataType.STRING, clazz.name())
                .unbreakable()
                .build();
    }

    public boolean isOnCooldown(Player player) {
        Long until = cooldowns.get(player.getUniqueId());
        return until != null && until > System.currentTimeMillis();
    }

    public long remainingCooldownSeconds(Player player) {
        Long until = cooldowns.get(player.getUniqueId());
        if (until == null) return 0;
        return Math.max(0, (until - System.currentTimeMillis()) / 1000);
    }

    private void putOnCooldown(Player player, int seconds) {
        cooldowns.put(player.getUniqueId(), System.currentTimeMillis() + seconds * 1000L);
    }

    /** Called from PlayerInteractListener when a player right-clicks their ability item. */
    public void useAbility(Player player) {
        PlayerClass clazz = get(player);
        if (isOnCooldown(player)) {
            player.sendActionBar(com.oleh.csc.util.Text.legacy("§cЗдібність відновлюється: " + remainingCooldownSeconds(player) + "с"));
            return;
        }
        switch (clazz) {
            case WARRIOR -> whirlwind(player);
            case ARCHER -> volley(player);
            case ALCHEMIST -> toxicFlask(player);
            case VAMPIRE -> bloodDrain(player);
            case MAGE -> fireball(player);
            case TANK -> shieldBash(player);
        }
        putOnCooldown(player, clazz.getAbilityCooldownSeconds());
    }

    // ---- Active abilities ----

    private void whirlwind(Player player) {
        Location loc = player.getLocation();
        player.getWorld().spawnParticle(Particle.SWEEP_ATTACK, loc.clone().add(0, 1, 0), 12, 1, 0.3, 1);
        player.playSound(loc, Sound.ENTITY_PLAYER_ATTACK_SWEEP, 1f, 1f);
        for (LivingEntity entity : loc.getNearbyLivingEntities(3.5)) {
            if (entity.equals(player)) continue;
            entity.damage(player.getAttribute(Attribute.GENERIC_ATTACK_DAMAGE).getValue() * 1.4, player);
            Vector push = entity.getLocation().toVector().subtract(loc.toVector()).normalize().setY(0.3);
            entity.setVelocity(push.multiply(1.1));
        }
    }

    private void volley(Player player) {
        Location eye = player.getEyeLocation();
        Vector dir = eye.getDirection();
        for (int i = -2; i <= 2; i++) {
            Vector spread = rotateAroundY(dir.clone(), i * 7);
            Arrow arrow = player.getWorld().spawnArrow(eye, spread.normalize(), 3.2f, 2f);
            arrow.setShooter(player);
            arrow.setDamage(3.0);
        }
        player.playSound(eye, Sound.ENTITY_ARROW_SHOOT, 1f, 1.4f);
    }

    private Vector rotateAroundY(Vector v, double degrees) {
        double rad = Math.toRadians(degrees);
        double cos = Math.cos(rad);
        double sin = Math.sin(rad);
        double x = v.getX() * cos + v.getZ() * sin;
        double z = -v.getX() * sin + v.getZ() * cos;
        return new Vector(x, v.getY(), z);
    }

    private void toxicFlask(Player player) {
        Location loc = player.getEyeLocation();

        ItemStack potionItem = new ItemBuilder(Material.SPLASH_POTION).build();
        PotionMeta meta = (PotionMeta) potionItem.getItemMeta();
        meta.addCustomEffect(new PotionEffect(PotionEffectType.POISON, 160, 1), true);
        meta.setColor(Color.LIME);
        potionItem.setItemMeta(meta);

        ThrownPotion potion = player.getWorld().spawn(loc, ThrownPotion.class);
        potion.setItem(potionItem);
        potion.setShooter(player);
        potion.setVelocity(loc.getDirection().multiply(1.3));
        player.playSound(loc, Sound.ENTITY_WITCH_THROW, 1f, 1f);
    }

    private void bloodDrain(Player player) {
        Location loc = player.getLocation();
        player.getWorld().spawnParticle(Particle.DAMAGE_INDICATOR, loc.clone().add(0, 1, 0), 20, 2, 1, 2);
        double healed = 0;
        for (LivingEntity entity : loc.getNearbyLivingEntities(4.0)) {
            if (entity.equals(player)) continue;
            double dmg = 4.0;
            entity.damage(dmg, player);
            healed += dmg * 0.5;
        }
        double maxHp = player.getAttribute(Attribute.GENERIC_MAX_HEALTH).getValue();
        player.setHealth(Math.min(maxHp, player.getHealth() + healed));
        player.playSound(loc, Sound.ENTITY_GENERIC_DRINK, 1f, 0.6f);
    }

    private void fireball(Player player) {
        Location eye = player.getEyeLocation();
        SmallFireball fb = player.getWorld().spawn(eye, SmallFireball.class);
        fb.setShooter(player);
        fb.setDirection(eye.getDirection());
        fb.setYield(0f);
        fb.setIsIncendiary(true);
        player.playSound(eye, Sound.ENTITY_BLAZE_SHOOT, 1f, 1f);
    }

    private void shieldBash(Player player) {
        Location loc = player.getLocation();
        Vector facing = loc.getDirection();
        for (LivingEntity entity : loc.getNearbyLivingEntities(3.5)) {
            if (entity.equals(player)) continue;
            Vector toEntity = entity.getLocation().toVector().subtract(loc.toVector()).normalize();
            if (toEntity.dot(facing) < 0.3) continue; // only in front
            entity.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 60, 2));
            entity.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, 60, 1));
            entity.setVelocity(toEntity.multiply(1.4).setY(0.4));
            entity.damage(2.0, player);
        }
        player.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, 40, 1));
        player.playSound(loc, Sound.ITEM_SHIELD_BLOCK, 1f, 0.8f);
    }

    // ---- Passive hooks (called from listeners) ----

    /** Melee/ranged damage multiplier applied when this player deals damage. */
    public double passiveDamageMultiplier(Player player) {
        return switch (get(player)) {
            case WARRIOR -> 1.15;
            case ARCHER -> 1.20;
            default -> 1.0;
        };
    }

    /** Vampire lifesteal: call after confirming damage dealt by a vampire player. */
    public void applyVampireLifesteal(Player player, double damageDealt) {
        if (get(player) != PlayerClass.VAMPIRE) return;
        double heal = damageDealt * 0.10;
        var maxHealth = player.getAttribute(Attribute.GENERIC_MAX_HEALTH);
        if (maxHealth == null) return;
        player.setHealth(Math.min(maxHealth.getValue(), player.getHealth() + heal));
    }

    public boolean isTank(Player player) {
        return get(player) == PlayerClass.TANK;
    }

    public boolean isMage(Player player) {
        return get(player) == PlayerClass.MAGE;
    }
}
