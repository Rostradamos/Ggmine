package com.oleh.csc.util;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;

/**
 * Converts legacy "&sect;"-style color strings to Adventure Components,
 * since newer Paper API versions prefer sendActionBar(Component) /
 * sendMessage(Component) over the old deprecated String overloads.
 */
public final class Text {

    private Text() {
    }

    public static Component legacy(String message) {
        return LegacyComponentSerializer.legacySection().deserialize(message);
    }
}
