package com.oleh.csc.items;

import org.bukkit.enchantments.Enchantment;

/**
 * The enchantments the Upgrade Station (see UpgradeManager/UpgradeStationGUI)
 * knows how to level up. "Base" enchants (Sharpness/Power/Protection) are
 * always offered for their matching gear category, even starting at level
 * 0; the "bonus" enchants (Bane of Arthropods/Fire Aspect/Thorns) only
 * become upgradeable once the item already carries them - typically from
 * a lucky wave-reward roll (see WaveRewardItem).
 */
public enum UpgradeableEnchant {

    SHARPNESS(Enchantment.SHARPNESS, "Гострота", 5, 250),
    BANE_OF_ARTHROPODS(Enchantment.BANE_OF_ARTHROPODS, "Загибель членистоногих", 5, 200),
    FIRE_ASPECT(Enchantment.FIRE_ASPECT, "Полум'я", 2, 400),
    POWER(Enchantment.POWER, "Сила (лук)", 5, 300),
    PROTECTION(Enchantment.PROTECTION, "Захист", 4, 300),
    // Named "Колючки" (not "Шипи") to avoid confusion with HeavyItem.SPIKES, the unrelated paid block+reflect utility item.
    THORNS(Enchantment.THORNS, "Колючки (Thorns)", 3, 500);

    private final Enchantment enchantment;
    private final String displayName;
    private final int maxLevel;
    private final int pricePerLevel;

    UpgradeableEnchant(Enchantment enchantment, String displayName, int maxLevel, int pricePerLevel) {
        this.enchantment = enchantment;
        this.displayName = displayName;
        this.maxLevel = maxLevel;
        this.pricePerLevel = pricePerLevel;
    }

    public Enchantment getEnchantment() {
        return enchantment;
    }

    public String getDisplayName() {
        return displayName;
    }

    public int getMaxLevel() {
        return maxLevel;
    }

    /** Gold cost to go from (targetLevel - 1) to targetLevel. */
    public int priceFor(int targetLevel) {
        return pricePerLevel * targetLevel;
    }
}
