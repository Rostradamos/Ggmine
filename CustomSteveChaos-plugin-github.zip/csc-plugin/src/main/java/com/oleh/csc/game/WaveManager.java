package com.oleh.csc.game;

import com.oleh.csc.CSCPlugin;
import com.oleh.csc.arena.Arena;
import com.oleh.csc.util.Keys;
import org.bukkit.Location;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

/**
 * Builds the mob composition for a given wave number and spawns it around
 * the arena's configured mob-spawn points. Every N waves (configurable,
 * default 10) a boosted boss replaces the regular pack.
 */
public class WaveManager {

    private static final Random RANDOM = new Random();
    private static final EntityType[] REGULAR_POOL = {
            EntityType.ZOMBIE, EntityType.SKELETON, EntityType.SPIDER,
            EntityType.HUSK, EntityType.STRAY, EntityType.ZOMBIE_VILLAGER
    };

    private static final Map<UUID, BukkitTask> BOSS_TASKS = new HashMap<>();

    public static List<LivingEntity> spawnWave(CSCPlugin plugin, Game game) {
        Arena arena = game.getArena();
        List<Location> spawnPoints = arena.getMobSpawnPoints();
        List<LivingEntity> spawned = new ArrayList<>();
        if (spawnPoints.isEmpty()) return spawned;

        int wave = game.getWave();

        if (game.isBossWave()) {
            int bossCount = Math.max(1, game.getPlayers().size() / 4);
            for (int i = 0; i < bossCount; i++) {
                Location at = (i == 0 && arena.getBossSpawnPoint() != null)
                        ? arena.getBossSpawnPoint()
                        : spawnPoints.get(RANDOM.nextInt(spawnPoints.size()));
                spawned.add(spawnBoss(plugin, game, at, wave));
            }
            // a handful of adds alongside the boss to keep it from being a 1v1 stand-still
            int addCount = Math.min(6, 2 + wave / 10);
            spawned.addAll(spawnRegulars(plugin, game, spawnPoints, addCount, wave));
        } else {
            int count = Math.min(24, 3 + (int) Math.ceil(wave * 1.5) + game.getPlayers().size());
            spawned.addAll(spawnRegulars(plugin, game, spawnPoints, count, wave));
        }
        return spawned;
    }

    private static List<LivingEntity> spawnRegulars(CSCPlugin plugin, Game game, List<Location> points, int count, int wave) {
        List<LivingEntity> list = new ArrayList<>();
        double healthMult = 1.0 + wave * 0.08;
        double damageMult = 1.0 + wave * 0.05;
        for (int i = 0; i < count; i++) {
            Location at = points.get(RANDOM.nextInt(points.size()));
            EntityType type = REGULAR_POOL[RANDOM.nextInt(REGULAR_POOL.length)];
            LivingEntity entity = (LivingEntity) at.getWorld().spawnEntity(at, type);
            scaleAttributes(entity, healthMult, damageMult);
            tagMob(plugin, entity, game.getArena().getName(), false);
            list.add(entity);
        }
        return list;
    }

    private static LivingEntity spawnBoss(CSCPlugin plugin, Game game, Location at, int wave) {
        LivingEntity boss = (LivingEntity) at.getWorld().spawnEntity(at, EntityType.ZOMBIE);
        boss.setCustomName("§c✦ Босс хвилі " + wave + " ✦");
        boss.setCustomNameVisible(true);
        boss.setGlowing(true);

        var maxHealthAttr = boss.getAttribute(Attribute.GENERIC_MAX_HEALTH);
        double baseHealth = 60 + wave * 8.0;
        if (maxHealthAttr != null) maxHealthAttr.setBaseValue(baseHealth);
        boss.setHealth(baseHealth);

        var dmgAttr = boss.getAttribute(Attribute.GENERIC_ATTACK_DAMAGE);
        if (dmgAttr != null) dmgAttr.setBaseValue(6 + wave * 0.6);

        var speedAttr = boss.getAttribute(Attribute.GENERIC_MOVEMENT_SPEED);
        if (speedAttr != null) speedAttr.setBaseValue(speedAttr.getBaseValue() * 1.15);

        var kbAttr = boss.getAttribute(Attribute.GENERIC_KNOCKBACK_RESISTANCE);
        if (kbAttr != null) kbAttr.setBaseValue(1.0);

        var equipment = boss.getEquipment();
        if (equipment != null) {
            equipment.setHelmet(new ItemStack(org.bukkit.Material.NETHERITE_HELMET));
            equipment.setChestplate(new ItemStack(org.bukkit.Material.DIAMOND_CHESTPLATE));
            equipment.setItemInMainHand(new ItemStack(org.bukkit.Material.IRON_SWORD));
            equipment.setHelmetDropChance(0f);
            equipment.setChestplateDropChance(0f);
            equipment.setItemInMainHandDropChance(0f);
        }

        tagMob(plugin, boss, game.getArena().getName(), true);

        // Periodic ground-slam: AoE knockback + damage to nearby alive players every 7s.
        BukkitTask task = org.bukkit.Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (boss.isDead() || !boss.isValid()) return;
            Location loc = boss.getLocation();
            boss.getWorld().spawnParticle(org.bukkit.Particle.EXPLOSION, loc, 1);
            for (var nearby : loc.getNearbyLivingEntities(4.5)) {
                if (!(nearby instanceof Player player)) continue;
                if (!game.getAlivePlayers().contains(player.getUniqueId())) continue;
                player.damage(dmgAttr != null ? dmgAttr.getBaseValue() * 0.8 : 6.0, boss);
                var push = player.getLocation().toVector().subtract(loc.toVector()).normalize().setY(0.5);
                player.setVelocity(push.multiply(1.3));
            }
        }, 140L, 140L);
        BOSS_TASKS.put(boss.getUniqueId(), task);

        return boss;
    }

    public static void cancelBossTask(UUID bossId) {
        BukkitTask task = BOSS_TASKS.remove(bossId);
        if (task != null) task.cancel();
    }

    private static void scaleAttributes(LivingEntity entity, double healthMult, double damageMult) {
        var maxHealthAttr = entity.getAttribute(Attribute.GENERIC_MAX_HEALTH);
        if (maxHealthAttr != null) {
            double newMax = maxHealthAttr.getBaseValue() * healthMult;
            maxHealthAttr.setBaseValue(newMax);
            entity.setHealth(newMax);
        }
        var dmgAttr = entity.getAttribute(Attribute.GENERIC_ATTACK_DAMAGE);
        if (dmgAttr != null) {
            dmgAttr.setBaseValue(dmgAttr.getBaseValue() * damageMult);
        }
    }

    private static void tagMob(CSCPlugin plugin, LivingEntity entity, String arenaName, boolean boss) {
        entity.getPersistentDataContainer().set(Keys.IS_WAVE_MOB, PersistentDataType.STRING, arenaName);
        if (boss) {
            entity.getPersistentDataContainer().set(Keys.IS_BOSS, PersistentDataType.STRING, arenaName);
        }
        entity.setRemoveWhenFarAway(false);
    }
}
