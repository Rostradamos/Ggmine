package com.oleh.csc;

import com.oleh.csc.arena.ArenaManager;
import com.oleh.csc.classes.ClassManager;
import com.oleh.csc.commands.CSCCommand;
import com.oleh.csc.duel.AutoDuelManager;
import com.oleh.csc.economy.EconomyManager;
import com.oleh.csc.game.GameManager;
import com.oleh.csc.items.HeavyItemManager;
import com.oleh.csc.items.UpgradeManager;
import com.oleh.csc.listeners.ArenaChestListener;
import com.oleh.csc.listeners.CombatListener;
import com.oleh.csc.listeners.GUIListener;
import com.oleh.csc.listeners.PlayerConnectionListener;
import com.oleh.csc.util.Keys;
import org.bukkit.plugin.java.JavaPlugin;

public final class CSCPlugin extends JavaPlugin {

    private static CSCPlugin instance;

    private CscConfig cscConfig;
    private ArenaManager arenaManager;
    private GameManager gameManager;
    private ClassManager classManager;
    private EconomyManager economyManager;
    private HeavyItemManager heavyItemManager;
    private UpgradeManager upgradeManager;
    private AutoDuelManager autoDuelManager;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();
        Keys.init(this);

        this.cscConfig = new CscConfig(this);
        this.arenaManager = new ArenaManager(this);
        this.gameManager = new GameManager(this);
        this.classManager = new ClassManager(this);
        this.economyManager = new EconomyManager(this);
        this.heavyItemManager = new HeavyItemManager(this);
        this.upgradeManager = new UpgradeManager(this);
        this.autoDuelManager = new AutoDuelManager(this);

        arenaManager.loadAll();
        economyManager.load();
        heavyItemManager.startRegenTask();

        getServer().getPluginManager().registerEvents(new CombatListener(this), this);
        getServer().getPluginManager().registerEvents(new GUIListener(this), this);
        getServer().getPluginManager().registerEvents(new PlayerConnectionListener(this), this);
        getServer().getPluginManager().registerEvents(new ArenaChestListener(this), this);

        CSCCommand executor = new CSCCommand(this);
        var command = getCommand("csc");
        if (command != null) {
            command.setExecutor(executor);
            command.setTabCompleter(executor);
        }

        getLogger().info("Custom Steve Chaos увімкнено. Арен завантажено: " + arenaManager.getAll().size());
    }

    @Override
    public void onDisable() {
        if (economyManager != null) economyManager.save();
        if (heavyItemManager != null) heavyItemManager.stopRegenTask();
    }

    public static CSCPlugin getInstance() {
        return instance;
    }

    public CscConfig getCscConfig() {
        return cscConfig;
    }

    public ArenaManager getArenaManager() {
        return arenaManager;
    }

    public GameManager getGameManager() {
        return gameManager;
    }

    public ClassManager getClassManager() {
        return classManager;
    }

    public EconomyManager getEconomyManager() {
        return economyManager;
    }

    public HeavyItemManager getHeavyItemManager() {
        return heavyItemManager;
    }

    public UpgradeManager getUpgradeManager() {
        return upgradeManager;
    }

    public AutoDuelManager getAutoDuelManager() {
        return autoDuelManager;
    }
}
