package com.oleh.csc.items;

import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.potion.PotionType;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * The free "choose 1 of 8" reward pool offered after a wave is cleared
 * (DropChoiceGUI randomly samples up to 8 of these each time - the pool
 * itself can hold more than 8 entries). These are plain, physical
 * gear/consumable upgrades (a sword, a bow, armor, effect arrows, a
 * potion) - NOT the 8 "heavy" items (Midas, the upgrade books, Spikes,
 * Rebirth, Jump, Shard - see {@link HeavyItem}), which only ever cost
 * gold in {@code /csc shop}.
 *
 * Some rolls add a random "bonus" enchant on top of the gear's always-on
 * base enchant (Sharpness for swords, Protection for armor): a sword can
 * come out already carrying Bane of Arthropods or Fire Aspect I, an armor
 * piece already carrying Thorns I. That bonus enchant then becomes
 * something the Upgrade Station (see UpgradeManager) can level up
 * further, right alongside the base one.
 *
 * Every bow this plugin ever hands out (this reward, class starter kits -
 * see ClassManager#applyKit) is permanently enchanted with Infinity.
 */
public enum WaveRewardItem {

    IRON_SWORD("Залізний меч", Material.IRON_SWORD,
            "§7Гострий залізний меч.",
            "§7Інколи трапляється з бонусним",
            "§7зачаруванням (Загибель членистоногих",
            "§7або Полум'я, рівень I)."),

    DIAMOND_SWORD("Діамантовий меч", Material.DIAMOND_SWORD,
            "§7Міцний діамантовий меч.",
            "§7Інколи трапляється з бонусним",
            "§7зачаруванням (Загибель членистоногих",
            "§7або Полум'я, рівень I)."),

    BOW("Лук", Material.BOW,
            "§7Лук, завжди з §bБезкінечністю§7,",
            "§7+16 стріл у комплекті."),

    ARROWS("Стріли", Material.ARROW,
            "§7Поповнення: §f16 стріл§7."),

    POISON_ARROWS("Отруйні стріли", Material.TIPPED_ARROW,
            "§78 стріл з ефектом §2Отрути§7."),

    SLOWNESS_ARROWS("Стріли сповільнення", Material.TIPPED_ARROW,
            "§78 стріл з ефектом §eСповільнення§7."),

    SHIELD("Щит", Material.SHIELD,
            "§7Щит для блокування атак."),

    IRON_ARMOR_SET("Набір залізної броні", Material.IRON_CHESTPLATE,
            "§7Повний комплект залізної броні.",
            "§7Кожна частина інколи трапляється",
            "§7з бонусним зачаруванням Колючки I",
            "§7§o(Thorns, не плутати з предметом «Шипи»)."),

    GOLDEN_APPLE("Золоте яблуко", Material.GOLDEN_APPLE,
            "§7Миттєво лікує. §aВидається 2 шт§7."),

    STRENGTH_POTION("Зілля Сили", Material.POTION,
            "§7Зілля Сили на §f1:30§7.");

    private static final Random RANDOM = new Random();
    private static final double BONUS_ENCHANT_CHANCE = 0.35;

    private final String displayName;
    private final Material icon;
    private final List<String> description;

    WaveRewardItem(String displayName, Material icon, String... description) {
        this.displayName = displayName;
        this.icon = icon;
        this.description = List.of(description);
    }

    public String getDisplayName() {
        return displayName;
    }

    public Material getIcon() {
        return icon;
    }

    public List<String> lore() {
        return description;
    }

    /** Builds the actual item stack(s) to hand the player - rolled fresh each call, so call it once per offer and cache the result (see DropChoiceGUI). */
    public List<ItemStack> buildRewardStacks() {
        switch (this) {
            case IRON_SWORD -> {
                return List.of(sword(Material.IRON_SWORD));
            }
            case DIAMOND_SWORD -> {
                return List.of(sword(Material.DIAMOND_SWORD));
            }
            case BOW -> {
                ItemStack bow = new ItemStack(Material.BOW);
                bow.addUnsafeEnchantment(Enchantment.POWER, 1);
                bow.addUnsafeEnchantment(Enchantment.INFINITY, 1);
                return List.of(bow, new ItemStack(Material.ARROW, 16));
            }
            case ARROWS -> {
                return List.of(new ItemStack(Material.ARROW, 16));
            }
            case POISON_ARROWS -> {
                return List.of(tippedArrow(PotionType.POISON, 8));
            }
            case SLOWNESS_ARROWS -> {
                return List.of(tippedArrow(PotionType.SLOWNESS, 8));
            }
            case SHIELD -> {
                return List.of(new ItemStack(Material.SHIELD));
            }
            case IRON_ARMOR_SET -> {
                List<ItemStack> set = new ArrayList<>();
                set.add(armorPiece(Material.IRON_HELMET));
                set.add(armorPiece(Material.IRON_CHESTPLATE));
                set.add(armorPiece(Material.IRON_LEGGINGS));
                set.add(armorPiece(Material.IRON_BOOTS));
                return set;
            }
            case GOLDEN_APPLE -> {
                return List.of(new ItemStack(Material.GOLDEN_APPLE, 2));
            }
            case STRENGTH_POTION -> {
                ItemStack potion = new ItemStack(Material.POTION);
                PotionMeta meta = (PotionMeta) potion.getItemMeta();
                meta.setBasePotionType(PotionType.STRENGTH);
                potion.setItemMeta(meta);
                return List.of(potion);
            }
            default -> {
                return List.of();
            }
        }
    }

    private static ItemStack sword(Material material) {
        ItemStack sword = new ItemStack(material);
        sword.addUnsafeEnchantment(Enchantment.SHARPNESS, 1);
        if (RANDOM.nextDouble() < BONUS_ENCHANT_CHANCE) {
            Enchantment bonus = RANDOM.nextBoolean() ? Enchantment.BANE_OF_ARTHROPODS : Enchantment.FIRE_ASPECT;
            sword.addUnsafeEnchantment(bonus, 1);
        }
        return sword;
    }

    private static ItemStack armorPiece(Material material) {
        ItemStack piece = new ItemStack(material);
        piece.addUnsafeEnchantment(Enchantment.PROTECTION, 1);
        if (RANDOM.nextDouble() < BONUS_ENCHANT_CHANCE) {
            piece.addUnsafeEnchantment(Enchantment.THORNS, 1);
        }
        return piece;
    }

    private static ItemStack tippedArrow(PotionType type, int amount) {
        ItemStack arrow = new ItemStack(Material.TIPPED_ARROW, amount);
        PotionMeta meta = (PotionMeta) arrow.getItemMeta();
        meta.setBasePotionType(type);
        arrow.setItemMeta(meta);
        return arrow;
    }
}
