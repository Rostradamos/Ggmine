package com.oleh.csc.gui;

import com.oleh.csc.classes.PlayerClass;
import com.oleh.csc.util.ItemBuilder;
import com.oleh.csc.util.Keys;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.persistence.PersistentDataType;

public class ClassSelectGUI {

    public static void open(Player player) {
        CSCMenuHolder holder = new CSCMenuHolder(CSCMenuHolder.MenuType.CLASS_SELECT);
        Inventory inv = Bukkit.createInventory(holder, 27, "§8Обери свій клас");
        holder.setInventory(inv);

        int[] slots = {10, 11, 12, 14, 15, 16};
        PlayerClass[] classes = PlayerClass.values();
        for (int i = 0; i < classes.length && i < slots.length; i++) {
            PlayerClass clazz = classes[i];
            inv.setItem(slots[i], new ItemBuilder(clazz.getIcon())
                    .name("§e§l" + clazz.getDisplayName())
                    .lore(clazz.lore())
                    .tag(Keys.CLASS_SELECT_ITEM, PersistentDataType.STRING, clazz.name())
                    .hideFlags()
                    .build());
        }

        player.openInventory(inv);
    }
}
