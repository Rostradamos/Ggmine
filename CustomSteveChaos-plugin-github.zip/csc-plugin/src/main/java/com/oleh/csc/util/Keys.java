package com.oleh.csc.util;

import org.bukkit.NamespacedKey;
import org.bukkit.plugin.Plugin;

/**
 * Central place for every NamespacedKey the plugin uses to tag items/entities.
 */
public class Keys {

    public static NamespacedKey ABILITY_ITEM;
    public static NamespacedKey UTILITY_ITEM;
    public static NamespacedKey CLASS_SELECT_ITEM;
    public static NamespacedKey WAVE_REWARD_CHOICE;
    public static NamespacedKey SHOP_BUY_ITEM;
    public static NamespacedKey MENU_CLOSE_BUTTON;
    public static NamespacedKey UPGRADE_BUTTON;
    public static NamespacedKey IS_BOSS;
    public static NamespacedKey IS_WAVE_MOB;

    public static void init(Plugin plugin) {
        ABILITY_ITEM = new NamespacedKey(plugin, "ability_item");
        UTILITY_ITEM = new NamespacedKey(plugin, "utility_item");
        CLASS_SELECT_ITEM = new NamespacedKey(plugin, "class_select_item");
        WAVE_REWARD_CHOICE = new NamespacedKey(plugin, "wave_reward_choice");
        SHOP_BUY_ITEM = new NamespacedKey(plugin, "shop_buy_item");
        MENU_CLOSE_BUTTON = new NamespacedKey(plugin, "menu_close_button");
        UPGRADE_BUTTON = new NamespacedKey(plugin, "upgrade_button");
        IS_BOSS = new NamespacedKey(plugin, "is_boss");
        IS_WAVE_MOB = new NamespacedKey(plugin, "is_wave_mob");
    }
}
