package com.oleh.csc.arena;

import org.bukkit.Location;

import java.util.ArrayList;
import java.util.List;

/**
 * A configured PvE arena: lobby point, mob spawn points scattered around
 * a flat square map, an optional boss spawn, a pair of duel spawns used
 * by the separate PvP duel mode, and the physical chest(s) that open the
 * shop / upgrade-station GUIs in-world (no player command for either).
 */
public class Arena {

    private final String name;
    private Location lobby;
    private final List<Location> mobSpawnPoints = new ArrayList<>();
    private Location bossSpawnPoint;
    private Location duelSpawn1;
    private Location duelSpawn2;
    private final List<Location> shopChestPoints = new ArrayList<>();
    private final List<Location> upgradeChestPoints = new ArrayList<>();
    private int minPlayers = 1;
    private int maxPlayers = 8;

    public Arena(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public Location getLobby() {
        return lobby;
    }

    public void setLobby(Location lobby) {
        this.lobby = lobby;
    }

    public List<Location> getMobSpawnPoints() {
        return mobSpawnPoints;
    }

    public void addMobSpawnPoint(Location loc) {
        mobSpawnPoints.add(loc);
    }

    public Location getBossSpawnPoint() {
        return bossSpawnPoint != null ? bossSpawnPoint
                : (mobSpawnPoints.isEmpty() ? lobby : mobSpawnPoints.get(0));
    }

    public void setBossSpawnPoint(Location bossSpawnPoint) {
        this.bossSpawnPoint = bossSpawnPoint;
    }

    public Location getDuelSpawn1() {
        return duelSpawn1;
    }

    public void setDuelSpawn1(Location duelSpawn1) {
        this.duelSpawn1 = duelSpawn1;
    }

    public Location getDuelSpawn2() {
        return duelSpawn2;
    }

    public void setDuelSpawn2(Location duelSpawn2) {
        this.duelSpawn2 = duelSpawn2;
    }

    public int getMinPlayers() {
        return minPlayers;
    }

    public void setMinPlayers(int minPlayers) {
        this.minPlayers = minPlayers;
    }

    public int getMaxPlayers() {
        return maxPlayers;
    }

    public void setMaxPlayers(int maxPlayers) {
        this.maxPlayers = maxPlayers;
    }

    public boolean isReady() {
        return lobby != null && !mobSpawnPoints.isEmpty();
    }

    public boolean isDuelReady() {
        return duelSpawn1 != null && duelSpawn2 != null;
    }

    public List<Location> getShopChestPoints() {
        return shopChestPoints;
    }

    public void addShopChestPoint(Location loc) {
        shopChestPoints.add(loc);
    }

    public boolean isShopChest(Location blockLoc) {
        for (Location loc : shopChestPoints) {
            if (sameBlock(loc, blockLoc)) return true;
        }
        return false;
    }

    public List<Location> getUpgradeChestPoints() {
        return upgradeChestPoints;
    }

    public void addUpgradeChestPoint(Location loc) {
        upgradeChestPoints.add(loc);
    }

    public boolean isUpgradeChest(Location blockLoc) {
        for (Location loc : upgradeChestPoints) {
            if (sameBlock(loc, blockLoc)) return true;
        }
        return false;
    }

    private boolean sameBlock(Location a, Location b) {
        if (a == null || b == null) return false;
        if (a.getWorld() == null || b.getWorld() == null) return false;
        return a.getWorld().equals(b.getWorld())
                && a.getBlockX() == b.getBlockX()
                && a.getBlockY() == b.getBlockY()
                && a.getBlockZ() == b.getBlockZ();
    }
}
