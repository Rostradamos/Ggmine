package com.oleh.csc.gui;

import com.oleh.csc.CSCPlugin;
import com.oleh.csc.items.WaveRewardItem;
import com.oleh.csc.util.ItemBuilder;
import com.oleh.csc.util.Keys;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * The free "choose 1 of 8" reward offered to every surviving player right
 * after a wave is cleared - mirrors CSC's real wave reward screen. These
 * are simple physical items (a sword, a bow, armor, effect arrows, a
 * potion) handed straight to the player's inventory; the 8 "heavy" items
 * (Midas, the upgrade books, Spikes, Rebirth, Jump, Shard) are deliberately
 * NOT part of this free pool - they only ever cost gold in {@code /csc shop}.
 *
 * The {@link WaveRewardItem} pool can hold more than 8 entries - each offer
 * randomly samples up to 8 of them. Some of those entries roll a random
 * bonus (a sword's Bane of Arthropods/Fire Aspect, an armor piece's
 * Thorns) once per offer; the result is cached on the {@link CSCMenuHolder}
 * keyed by slot so a click always grants exactly what was shown, never a
 * fresh re-roll.
 */
public class DropChoiceGUI {

    private static final int MAX_OPTIONS = 8;

    public static void open(CSCPlugin plugin, Player player) {
        List<WaveRewardItem> pool = new ArrayList<>(List.of(WaveRewardItem.values()));
        Collections.shuffle(pool);
        int count = Math.min(MAX_OPTIONS, pool.size());

        CSCMenuHolder holder = new CSCMenuHolder(CSCMenuHolder.MenuType.DROP_CHOICE);
        Inventory inv = Bukkit.createInventory(holder, 9, "§8Нагорода за хвилю — обери 1 з " + count);
        holder.setInventory(inv);

        Map<Integer, List<ItemStack>> rolled = new HashMap<>();
        for (int i = 0; i < count; i++) {
            WaveRewardItem item = pool.get(i);
            List<ItemStack> stacks = item.buildRewardStacks(); // rolled once here, cached for the click handler
            rolled.put(i, stacks);

            List<String> lore = new ArrayList<>(item.lore());
            lore.add("");
            lore.add("§aБЕЗКОШТОВНО §7— клікни, щоб забрати");

            ItemStack base = stacks.isEmpty() ? new ItemStack(item.getIcon()) : stacks.get(0).clone();
            ItemStack display = new ItemBuilder(base)
                    .amount(1)
                    .name("§e§l" + item.getDisplayName())
                    .lore(lore)
                    .tag(Keys.WAVE_REWARD_CHOICE, PersistentDataType.STRING, item.name())
                    .build();
            inv.setItem(i, display);
        }
        holder.setRewardStacks(rolled);

        player.openInventory(inv);
    }
}
