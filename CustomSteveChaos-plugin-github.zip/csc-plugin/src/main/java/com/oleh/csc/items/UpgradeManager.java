package com.oleh.csc.items;

import com.oleh.csc.CSCPlugin;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;

/**
 * Lets a player pay gold to level up an enchantment on any gear item in
 * their inventory, through the Upgrade Station chest GUI
 * (see UpgradeStationGUI). Every sword always offers Sharpness, every bow
 * Power, every armor piece Protection - plus whatever "bonus" enchant
 * (Bane of Arthropods / Fire Aspect / Thorns) that specific item already
 * happens to carry, e.g. from a wave-reward roll (see WaveRewardItem).
 */
public class UpgradeManager {

    private final CSCPlugin plugin;

    public UpgradeManager(CSCPlugin plugin) {
        this.plugin = plugin;
    }

    private boolean isSword(Material type) {
        return type.name().endsWith("_SWORD");
    }

    private boolean isArmor(Material type) {
        String name = type.name();
        return name.endsWith("_HELMET") || name.endsWith("_CHESTPLATE")
                || name.endsWith("_LEGGINGS") || name.endsWith("_BOOTS");
    }

    private boolean isBow(Material type) {
        return type == Material.BOW;
    }

    /** The one enchant every item of this gear category can always be upgraded in, even starting from level 0. Null if the item isn't recognized gear. */
    private UpgradeableEnchant baseEnchantFor(ItemStack item) {
        if (item == null) return null;
        Material type = item.getType();
        if (isSword(type)) return UpgradeableEnchant.SHARPNESS;
        if (isBow(type)) return UpgradeableEnchant.POWER;
        if (isArmor(type)) return UpgradeableEnchant.PROTECTION;
        return null;
    }

    /** Every enchant this specific item can currently be upgraded in: its base one, plus any bonus enchant it already carries. Empty if the item isn't recognized gear. */
    public List<UpgradeableEnchant> availableUpgrades(ItemStack item) {
        List<UpgradeableEnchant> options = new ArrayList<>();
        UpgradeableEnchant base = baseEnchantFor(item);
        if (base == null) return options;
        options.add(base);
        for (UpgradeableEnchant ue : UpgradeableEnchant.values()) {
            if (ue == base) continue;
            if (item.containsEnchantment(ue.getEnchantment())) {
                options.add(ue);
            }
        }
        return options;
    }

    public int currentLevel(ItemStack item, UpgradeableEnchant ue) {
        if (item == null) return 0;
        return item.getEnchantmentLevel(ue.getEnchantment());
    }

    /** Attempts to upgrade one level; mutates the item in place and withdraws gold on success. */
    public boolean upgrade(Player player, ItemStack item, UpgradeableEnchant ue) {
        int current = currentLevel(item, ue);
        int next = current + 1;
        if (next > ue.getMaxLevel()) {
            player.sendMessage("§cДосягнуто максимальний рівень: §f" + ue.getDisplayName());
            return false;
        }
        int price = ue.priceFor(next);
        if (!plugin.getEconomyManager().has(player, price)) {
            player.sendMessage("§cНедостатньо золота (потрібно " + price + ").");
            return false;
        }
        plugin.getEconomyManager().withdraw(player, price);
        item.addUnsafeEnchantment(ue.getEnchantment(), next);
        player.sendMessage("§a" + ue.getDisplayName() + " прокачано до рівня §f" + next + "§a!");
        return true;
    }
}
