package com.oleh.csc.util;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.configuration.ConfigurationSection;

public class LocationUtil {

    public static void save(ConfigurationSection section, String path, Location loc) {
        if (loc == null) {
            section.set(path, null);
            return;
        }
        String base = path + ".";
        section.set(base + "world", loc.getWorld().getName());
        section.set(base + "x", loc.getX());
        section.set(base + "y", loc.getY());
        section.set(base + "z", loc.getZ());
        section.set(base + "yaw", loc.getYaw());
        section.set(base + "pitch", loc.getPitch());
    }

    public static Location load(ConfigurationSection section, String path) {
        if (section == null || !section.isSet(path + ".world")) return null;
        String worldName = section.getString(path + ".world");
        var world = Bukkit.getWorld(worldName);
        if (world == null) return null;
        double x = section.getDouble(path + ".x");
        double y = section.getDouble(path + ".y");
        double z = section.getDouble(path + ".z");
        float yaw = (float) section.getDouble(path + ".yaw");
        float pitch = (float) section.getDouble(path + ".pitch");
        return new Location(world, x, y, z, yaw, pitch);
    }
}
