package com.oleh.csc.listeners;

import com.oleh.csc.CSCPlugin;
import com.oleh.csc.arena.Arena;
import com.oleh.csc.gui.ShopGUI;
import com.oleh.csc.gui.UpgradeStationGUI;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;

/**
 * Lets players open the shop/upgrade-station GUIs by right-clicking a
 * physical chest the admin placed and registered via
 * {@code /csc admin addshopchest|addupgradechest} - there is no
 * player-facing command for either menu, only these in-world chests.
 */
public class ArenaChestListener implements Listener {

    private final CSCPlugin plugin;

    public ArenaChestListener(CSCPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        Block block = event.getClickedBlock();
        if (block == null || block.getType() != Material.CHEST) return;

        Player player = event.getPlayer();
        var gameOpt = plugin.getGameManager().getGameOf(player);
        if (gameOpt.isEmpty()) return;
        Arena arena = gameOpt.get().getArena();

        if (arena.isShopChest(block.getLocation())) {
            event.setCancelled(true);
            ShopGUI.open(plugin, player);
        } else if (arena.isUpgradeChest(block.getLocation())) {
            event.setCancelled(true);
            UpgradeStationGUI.open(plugin, player);
        }
    }
}
