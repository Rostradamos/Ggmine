package com.oleh.csc.game;

import com.oleh.csc.CSCPlugin;
import com.oleh.csc.arena.Arena;
import com.oleh.csc.gui.DropChoiceGUI;
import com.oleh.csc.util.PlayerSnapshot;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.attribute.Attribute;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * One running instance of the PvE wave-survival minigame on a given arena.
 */
public class Game {

    private final CSCPlugin plugin;
    private final Arena arena;
    private GameState state = GameState.WAITING;

    private final Set<UUID> players = new HashSet<>();
    private final Set<UUID> alivePlayers = new HashSet<>();
    private final Map<UUID, PlayerSnapshot> snapshots = new HashMap<>();
    private final Set<UUID> aliveMobs = new HashSet<>();
    private final Map<UUID, Integer> lives = new HashMap<>();

    private int wave = 0;
    private int waveMobTotal = 1;
    private BukkitTask countdownTask;
    private BukkitTask betweenWaveTask;
    private int countdownSeconds;
    private final BossBar bossBar;

    public Game(CSCPlugin plugin, Arena arena) {
        this.plugin = plugin;
        this.arena = arena;
        this.bossBar = Bukkit.createBossBar("§6Custom Steve Chaos", BarColor.YELLOW, BarStyle.SOLID);
    }

    public Arena getArena() {
        return arena;
    }

    public GameState getState() {
        return state;
    }

    public int getWave() {
        return wave;
    }

    public Set<UUID> getPlayers() {
        return players;
    }

    public Set<UUID> getAlivePlayers() {
        return alivePlayers;
    }

    public boolean isBossWave() {
        return wave > 0 && wave % plugin.getCscConfig().getBossEveryWaves() == 0;
    }

    public boolean join(Player player) {
        if (state != GameState.WAITING && state != GameState.STARTING) {
            player.sendMessage("§cГра вже триває, зачекай наступний раунд.");
            return false;
        }
        if (players.size() >= arena.getMaxPlayers()) {
            player.sendMessage("§cАрена заповнена.");
            return false;
        }
        snapshots.put(player.getUniqueId(), PlayerSnapshot.capture(player));
        players.add(player.getUniqueId());
        alivePlayers.add(player.getUniqueId());
        player.setGameMode(GameMode.ADVENTURE);
        player.teleport(arena.getLobby());
        bossBar.addPlayer(player);
        broadcast("§a" + player.getName() + " §7приєднався (" + players.size() + "/" + arena.getMaxPlayers() + ")");

        if (players.size() >= arena.getMinPlayers() && state == GameState.WAITING) {
            startCountdown();
        }
        return true;
    }

    public void leave(Player player) {
        UUID id = player.getUniqueId();
        boolean was = players.remove(id);
        alivePlayers.remove(id);
        lives.remove(id);
        bossBar.removePlayer(player);
        if (!was) return;

        PlayerSnapshot snap = snapshots.remove(id);
        if (snap != null) snap.restore(player);
        player.setGameMode(GameMode.SURVIVAL);
        plugin.getClassManager().clear(player);
        plugin.getHeavyItemManager().clear(player);
        plugin.getAutoDuelManager().forfeit(player);

        if (state == GameState.INGAME || state == GameState.STARTING) {
            broadcast("§e" + player.getName() + " §7покинув гру");
        }

        if (players.isEmpty()) {
            reset();
        } else if (state == GameState.STARTING && players.size() < arena.getMinPlayers() && countdownTask != null) {
            countdownTask.cancel();
            countdownTask = null;
            state = GameState.WAITING;
            broadcast("§7Недостатньо гравців, відлік скасовано.");
        } else if (state == GameState.INGAME && alivePlayers.isEmpty()) {
            endGame(false);
        }
    }

    private void startCountdown() {
        state = GameState.STARTING;
        countdownSeconds = plugin.getCscConfig().getStartCountdownSeconds();
        countdownTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (countdownSeconds <= 0) {
                countdownTask.cancel();
                countdownTask = null;
                start();
                return;
            }
            if (countdownSeconds <= 5 || countdownSeconds % 10 == 0) {
                broadcast("§eГра починається через §f" + countdownSeconds + "§e...");
            }
            countdownSeconds--;
        }, 0L, 20L);
    }

    private void start() {
        state = GameState.INGAME;
        wave = 0;
        lives.clear();
        for (UUID id : players) {
            Player p = Bukkit.getPlayer(id);
            if (p == null) continue;
            if (!plugin.getClassManager().hasSelected(p)) {
                plugin.getClassManager().select(p, com.oleh.csc.classes.PlayerClass.WARRIOR);
            }
            plugin.getClassManager().applyKit(p);
            p.setGameMode(GameMode.SURVIVAL);
            lives.put(id, plugin.getCscConfig().getLivesPerPlayer());
        }
        broadcast("§a§lГра почалась! Тримайтесь разом. §7(Життів: " + plugin.getCscConfig().getLivesPerPlayer() + ")");
        nextWave();
    }

    public int getLives(Player player) {
        return lives.getOrDefault(player.getUniqueId(), 0);
    }

    /** Used by the "Rebirth" heavy item to grant an extra life mid-game. */
    public void addLife(Player player, int delta) {
        lives.merge(player.getUniqueId(), delta, Integer::sum);
        player.sendMessage("§a+" + delta + " життя! Тепер: §f" + getLives(player));
    }

    public void nextWave() {
        if (state != GameState.INGAME) return;
        wave++;
        aliveMobs.clear();
        bossBar.setTitle("§6Хвиля " + wave + (isBossWave() ? " §c✦ БОСС" : ""));
        bossBar.setProgress(1.0);
        bossBar.setColor(isBossWave() ? BarColor.RED : BarColor.YELLOW);

        broadcast(isBossWave()
                ? "§c§lХВИЛЯ " + wave + " — З'являється БОСС!"
                : "§6Хвиля §f" + wave + "§6 почалась!");

        var spawned = com.oleh.csc.game.WaveManager.spawnWave(plugin, this);
        for (LivingEntity e : spawned) {
            aliveMobs.add(e.getUniqueId());
        }
        waveMobTotal = Math.max(1, aliveMobs.size());
        if (aliveMobs.isEmpty()) {
            // Safety net: nothing spawned (misconfigured arena) - just wait a bit then retry.
            Bukkit.getScheduler().runTaskLater(plugin, this::nextWave, 100L);
        }
    }

    public void onMobDeath(UUID mobId) {
        aliveMobs.remove(mobId);
        updateBossBarProgress();
        if (aliveMobs.isEmpty() && state == GameState.INGAME) {
            broadcast("§aХвиля " + wave + " завершена! Наступна через " + plugin.getCscConfig().getBetweenWaveSeconds() + "с.");
            offerWaveReward();
            if (wave >= plugin.getCscConfig().getDuelStartAfterWave()) {
                plugin.getAutoDuelManager().maybeStartDuel(this);
            }
            betweenWaveTask = Bukkit.getScheduler().runTaskLater(plugin, this::nextWave,
                    plugin.getCscConfig().getBetweenWaveSeconds() * 20L);
        }
    }

    /** Opens the free "pick 1 of 8" simple-gear reward menu for every surviving player. */
    private void offerWaveReward() {
        for (UUID id : alivePlayers) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) DropChoiceGUI.open(plugin, p);
        }
    }

    private void updateBossBarProgress() {
        double progress = aliveMobs.isEmpty() ? 0.0 : aliveMobs.size() / (double) waveMobTotal;
        bossBar.setProgress(Math.max(0.0, Math.min(1.0, progress)));
    }

    public boolean isAliveMob(UUID id) {
        return aliveMobs.contains(id);
    }

    /** Called when a player would otherwise have died. Burns one life and respawns them, or eliminates them if that was their last one. */
    public void onPlayerDown(Player player) {
        UUID id = player.getUniqueId();
        int remaining = lives.getOrDefault(id, 1) - 1;
        lives.put(id, remaining);

        if (remaining > 0) {
            respawn(player, remaining);
        } else {
            eliminate(player);
        }
    }

    private void respawn(Player player, int livesLeft) {
        var healthAttr = player.getAttribute(Attribute.GENERIC_MAX_HEALTH);
        if (healthAttr != null) player.setHealth(healthAttr.getValue());
        player.setFireTicks(0);
        player.setNoDamageTicks(40); // 2s grace so they're not instantly re-hit on respawn

        Location respawnPoint = arena.getLobby() != null ? arena.getLobby() : player.getLocation();
        player.teleport(respawnPoint);

        player.sendMessage("§eТи втратив життя! Залишилось: §c" + livesLeft + "§e/" + plugin.getCscConfig().getLivesPerPlayer());
        broadcast("§e☠ " + player.getName() + " §7втратив життя (" + livesLeft + " залишилось) на хвилі " + wave);
    }

    public void eliminate(Player player) {
        alivePlayers.remove(player.getUniqueId());
        player.setGameMode(GameMode.SPECTATOR);
        broadcast("§c☠ " + player.getName() + " §7вибув з гри на хвилі " + wave);
        if (alivePlayers.isEmpty()) {
            endGame(false);
        }
    }

    public void endGame(boolean victory) {
        if (state == GameState.ENDING) return;
        state = GameState.ENDING;
        if (betweenWaveTask != null) betweenWaveTask.cancel();
        int finalWave = wave;
        int reward = plugin.getCscConfig().getGoldPerWaveSurvived() * finalWave;

        for (UUID id : new HashSet<>(players)) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) {
                plugin.getEconomyManager().deposit(p, reward);
                p.sendMessage("§6Гру завершено. Досягнуто хвилі §f" + finalWave + "§6. Отримано §e" + reward + " золота§6.");
                PlayerSnapshot snap = snapshots.get(id);
                if (snap != null) snap.restore(p);
                p.setGameMode(GameMode.SURVIVAL);
                bossBar.removePlayer(p);
                plugin.getClassManager().clear(p);
                plugin.getHeavyItemManager().clear(p);
                plugin.getAutoDuelManager().forfeit(p);
            }
        }
        cleanupMobs();
        players.clear();
        alivePlayers.clear();
        snapshots.clear();
        lives.clear();
        reset();
    }

    private void cleanupMobs() {
        for (UUID id : aliveMobs) {
            var entity = Bukkit.getEntity(id);
            if (entity != null) entity.remove();
        }
        aliveMobs.clear();
    }

    private void reset() {
        state = GameState.WAITING;
        wave = 0;
        if (countdownTask != null) {
            countdownTask.cancel();
            countdownTask = null;
        }
        cleanupMobs();
    }

    public void broadcast(String message) {
        for (UUID id : players) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) p.sendMessage(message);
        }
    }
}
