package com.oleh.csc.listeners;

import com.oleh.csc.CSCPlugin;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;

public class PlayerConnectionListener implements Listener {

    private final CSCPlugin plugin;

    public PlayerConnectionListener(CSCPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        var player = event.getPlayer();
        // Game#leave() also forfeits any active auto-duel and clears class/heavy-item state.
        if (plugin.getGameManager().isInGame(player)) {
            plugin.getGameManager().leave(player);
        }
        plugin.getEconomyManager().save();
    }
}
