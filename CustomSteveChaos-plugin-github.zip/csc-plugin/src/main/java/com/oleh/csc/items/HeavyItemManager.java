package com.oleh.csc.items;

import com.oleh.csc.CSCPlugin;
import com.oleh.csc.util.ItemBuilder;
import com.oleh.csc.util.Keys;
import com.oleh.csc.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Owns the 8 "heavy items": the stacking upgrade books (Damage/Life/Regen)
 * and the one-time unlocks (Midas, Spikes, Rebirth, Jump, Shard). Unlike
 * the free post-wave reward (see {@link WaveRewardItem}), heavy items are
 * ONLY obtainable by spending gold in {@code /csc shop} - see purchase().
 */
public class HeavyItemManager {

    private final CSCPlugin plugin;

    private final Map<UUID, Map<HeavyItem, Integer>> stacks = new HashMap<>();
    private final Map<UUID, Set<HeavyItem>> oneTimeObtained = new HashMap<>();

    private final Map<UUID, Long> midasCooldown = new HashMap<>();
    private final Map<UUID, Long> jumpCooldown = new HashMap<>();
    private final Map<UUID, Long> spikesCooldown = new HashMap<>();
    private final Map<UUID, Long> spikesActiveUntil = new HashMap<>();

    private BukkitTask regenTask;

    public HeavyItemManager(CSCPlugin plugin) {
        this.plugin = plugin;
    }

    public void startRegenTask() {
        regenTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            for (Map.Entry<UUID, Map<HeavyItem, Integer>> entry : stacks.entrySet()) {
                int regenStacks = entry.getValue().getOrDefault(HeavyItem.REGEN_BOOK, 0);
                if (regenStacks <= 0) continue;
                Player p = Bukkit.getPlayer(entry.getKey());
                if (p == null || !plugin.getGameManager().isInGame(p)) continue;
                var attr = p.getAttribute(Attribute.GENERIC_MAX_HEALTH);
                if (attr == null) continue;
                double heal = 0.5 * regenStacks;
                p.setHealth(Math.min(attr.getValue(), p.getHealth() + heal));
            }
        }, 20L, 20L);
    }

    public void stopRegenTask() {
        if (regenTask != null) regenTask.cancel();
    }

    public void clear(Player player) {
        UUID id = player.getUniqueId();
        stacks.remove(id);
        oneTimeObtained.remove(id);
        midasCooldown.remove(id);
        jumpCooldown.remove(id);
        spikesCooldown.remove(id);
        spikesActiveUntil.remove(id);
    }

    public int getStacks(Player player, HeavyItem item) {
        return stacks.getOrDefault(player.getUniqueId(), Map.of()).getOrDefault(item, 0);
    }

    public boolean hasOneTime(Player player, HeavyItem item) {
        return oneTimeObtained.getOrDefault(player.getUniqueId(), Set.of()).contains(item);
    }

    public int currentPrice(Player player, HeavyItem item) {
        return item.getBasePrice() + getStacks(player, item) * item.getPriceIncrement();
    }

    /** Paid purchase via /csc shop - the only way to obtain a heavy item. */
    public boolean purchase(Player player, HeavyItem item) {
        if (item.isOneTime() && hasOneTime(player, item)) {
            player.sendMessage("§cТи вже маєш цей предмет.");
            return false;
        }
        int price = currentPrice(player, item);
        if (!plugin.getEconomyManager().has(player, price)) {
            player.sendMessage("§cНедостатньо золота (потрібно " + price + ").");
            return false;
        }
        plugin.getEconomyManager().withdraw(player, price);
        grant(player, item);
        return true;
    }

    private void grant(Player player, HeavyItem item) {
        UUID id = player.getUniqueId();
        if (item.isOneTime()) {
            oneTimeObtained.computeIfAbsent(id, k -> new HashSet<>()).add(item);
        } else {
            stacks.computeIfAbsent(id, k -> new HashMap<>()).merge(item, 1, Integer::sum);
        }
        applyEffect(player, item);
        player.sendMessage("§aОтримано: §f" + item.getDisplayName());
    }

    private void applyEffect(Player player, HeavyItem item) {
        switch (item) {
            case LIFE_BOOK -> {
                var attr = player.getAttribute(Attribute.GENERIC_MAX_HEALTH);
                if (attr != null) {
                    attr.setBaseValue(attr.getBaseValue() + 4.0); // +2 hearts
                    player.setHealth(Math.min(attr.getValue(), player.getHealth() + 4.0));
                }
            }
            case REBIRTH -> plugin.getGameManager().getGameOf(player).ifPresent(game -> game.addLife(player, 1));
            case SHARD -> plugin.getClassManager().unlockShard(player);
            case MIDAS, SPIKES, JUMP -> giveUtilityItem(player, item);
            case DAMAGE_BOOK, REGEN_BOOK -> {
                // Passive stat, read dynamically by CombatListener / the regen task above.
            }
        }
    }

    private void giveUtilityItem(Player player, HeavyItem item) {
        ItemStack stack = new ItemBuilder(item.getIcon())
                .name("§b✦ " + item.getDisplayName())
                .lore(item.lore())
                .tag(Keys.UTILITY_ITEM, PersistentDataType.STRING, item.name())
                .unbreakable()
                .build();
        player.getInventory().addItem(stack);
    }

    // ---- Combat hooks (used by CombatListener) ----

    public double getMeleeDamageBonus(Player player) {
        return getStacks(player, HeavyItem.DAMAGE_BOOK) * 1.0;
    }

    public double getRangedDamageBonus(Player player) {
        return getStacks(player, HeavyItem.DAMAGE_BOOK) * 0.5;
    }

    public boolean isSpikesActive(Player player) {
        Long until = spikesActiveUntil.get(player.getUniqueId());
        return until != null && until > System.currentTimeMillis();
    }

    // ---- Utility item activation (Midas / Spikes / Jump) ----

    public void useUtility(Player player, HeavyItem item) {
        switch (item) {
            case MIDAS -> useMidas(player);
            case SPIKES -> useSpikes(player);
            case JUMP -> useJump(player);
            default -> {
            }
        }
    }

    private boolean onCooldown(Map<UUID, Long> map, Player player) {
        Long until = map.get(player.getUniqueId());
        return until != null && until > System.currentTimeMillis();
    }

    private void setCooldown(Map<UUID, Long> map, Player player, int seconds) {
        map.put(player.getUniqueId(), System.currentTimeMillis() + seconds * 1000L);
    }

    private void useMidas(Player player) {
        if (onCooldown(midasCooldown, player)) {
            player.sendActionBar(Text.legacy("§cМідас ще відновлюється"));
            return;
        }
        LivingEntity target = null;
        double bestDistance = 6.0;
        for (LivingEntity entity : player.getLocation().getNearbyLivingEntities(6.0)) {
            if (!entity.getPersistentDataContainer().has(Keys.IS_WAVE_MOB, PersistentDataType.STRING)) continue;
            if (entity.getPersistentDataContainer().has(Keys.IS_BOSS, PersistentDataType.STRING)) continue;
            double distance = entity.getLocation().distance(player.getLocation());
            if (distance < bestDistance) {
                bestDistance = distance;
                target = entity;
            }
        }
        if (target == null) {
            player.sendMessage("§cНемає звичайного моба поруч для Мідаса.");
            return;
        }
        target.setHealth(0.0);
        plugin.getEconomyManager().deposit(player, 190);
        player.sendMessage("§6Мідас: моб вбитий, §e+190 золота§6!");
        setCooldown(midasCooldown, player, 45);
    }

    private void useSpikes(Player player) {
        if (onCooldown(spikesCooldown, player)) {
            player.sendActionBar(Text.legacy("§cШипи ще відновлюються"));
            return;
        }
        spikesActiveUntil.put(player.getUniqueId(), System.currentTimeMillis() + 6000L);
        player.sendMessage("§bШипи активовано на 6с!");
        setCooldown(spikesCooldown, player, 30);
    }

    private void useJump(Player player) {
        if (onCooldown(jumpCooldown, player)) {
            player.sendActionBar(Text.legacy("§cСтрибок ще відновлюється"));
            return;
        }
        player.setVelocity(player.getLocation().getDirection().multiply(1.8).setY(0.6));
        setCooldown(jumpCooldown, player, 20);
    }
}
