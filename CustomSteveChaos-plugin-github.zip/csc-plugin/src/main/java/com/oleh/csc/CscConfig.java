package com.oleh.csc;

/**
 * Typed accessors over config.yml's top-level settings (wave pacing,
 * economy, shop prices, duel defaults).
 */
public class CscConfig {

    private final CSCPlugin plugin;

    public CscConfig(CSCPlugin plugin) {
        this.plugin = plugin;
    }

    public int getStartCountdownSeconds() {
        return plugin.getConfig().getInt("settings.start-countdown-seconds", 20);
    }

    public int getBetweenWaveSeconds() {
        return plugin.getConfig().getInt("settings.between-wave-seconds", 10);
    }

    public int getBossEveryWaves() {
        return plugin.getConfig().getInt("settings.boss-every-waves", 10);
    }

    public int getLivesPerPlayer() {
        return plugin.getConfig().getInt("settings.lives-per-player", 3);
    }

    public int getGoldPerKill() {
        return plugin.getConfig().getInt("settings.gold-per-kill", 5);
    }

    public int getGoldPerBossKill() {
        return plugin.getConfig().getInt("settings.gold-per-boss-kill", 150);
    }

    public int getGoldPerWaveSurvived() {
        return plugin.getConfig().getInt("settings.gold-per-wave-survived", 10);
    }

    public double getStartingGold() {
        return plugin.getConfig().getDouble("settings.starting-gold", 100);
    }

    public int getDuelWinReward() {
        return plugin.getConfig().getInt("settings.duel-win-reward", 300);
    }

    /** Automatic duels start happening once this many waves have been cleared (CSC originally starts them after wave 3). */
    public int getDuelStartAfterWave() {
        return plugin.getConfig().getInt("settings.duel-start-after-wave", 3);
    }
}
