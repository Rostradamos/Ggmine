package com.oleh.csc.classes;

import org.bukkit.Material;

import java.util.Arrays;
import java.util.List;

/**
 * The six playable classes, modeled loosely after Custom Steve Chaos's
 * class roster (Swordsman, Archer, Alchemist, Vampire, Mage/Reincarnator,
 * Brute/Tank). Each class has one passive and one active ability.
 */
public enum PlayerClass {

    WARRIOR(
            "Воїн",
            Material.IRON_SWORD,
            "Ближній бій, бонусний урон мечем.",
            "Пасивка: +15% уроду в ближньому бою.",
            "Актив: Вихор клинка — AoE удар навколо себе.",
            6.0,
            20,
            6
    ),
    ARCHER(
            "Лучник",
            Material.BOW,
            "Дальній бій, залп стріл.",
            "Пасивка: +20% уроду від стріл, без відкидання від лука.",
            "Актив: Залп — миттєво випускає 5 стріл віялом.",
            4.0,
            16,
            8
    ),
    ALCHEMIST(
            "Алхімік",
            Material.BREWING_STAND,
            "Отруйні зілля та підтримка.",
            "Пасивка: регенерація 1 хп кожні 6 секунд.",
            "Актив: Токсична колба — кидає зілля, що труїть ворогів в área.",
            3.0,
            20,
            10
    ),
    VAMPIRE(
            "Вампір",
            Material.REDSTONE,
            "Висмоктує життя з ворогів.",
            "Пасивка: лікується на 10% від нанесеного уроду в ближньому бою.",
            "Актив: Висмоктування крові — хвиля навколо себе, лікує за нанесений урон.",
            4.0,
            18,
            12
    ),
    MAGE(
            "Маг",
            Material.BLAZE_POWDER,
            "Магічні снаряди, що ігнорують частину броні.",
            "Пасивка: магічний урон ігнорує 20% броні цілі.",
            "Актив: Вогняна куля — запускає вогняний снаряд, що підпалює ворогів.",
            3.0,
            16,
            7
    ),
    TANK(
            "Громило",
            Material.SHIELD,
            "Багато здоров'я, стан та приголомшення ворогів.",
            "Пасивка: +4 додаткових серця, стійкість до відкидання.",
            "Актив: Удар щитом — приголомшує і відкидає ворогів перед собою.",
            5.0,
            28,
            16
    );

    private final String displayName;
    private final Material icon;
    private final String shortDescription;
    private final String passiveDescription;
    private final String activeDescription;
    private final double baseDamage;
    private final int maxHealth; // in half-hearts (20 = 10 hearts)
    private final int abilityCooldownSeconds;

    PlayerClass(String displayName, Material icon, String shortDescription,
                String passiveDescription, String activeDescription,
                double baseDamage, int maxHealth, int abilityCooldownSeconds) {
        this.displayName = displayName;
        this.icon = icon;
        this.shortDescription = shortDescription;
        this.passiveDescription = passiveDescription;
        this.activeDescription = activeDescription;
        this.baseDamage = baseDamage;
        this.maxHealth = maxHealth;
        this.abilityCooldownSeconds = abilityCooldownSeconds;
    }

    public String getDisplayName() {
        return displayName;
    }

    public Material getIcon() {
        return icon;
    }

    public String getShortDescription() {
        return shortDescription;
    }

    public String getPassiveDescription() {
        return passiveDescription;
    }

    public String getActiveDescription() {
        return activeDescription;
    }

    public double getBaseDamage() {
        return baseDamage;
    }

    public int getMaxHealth() {
        return maxHealth;
    }

    public int getAbilityCooldownSeconds() {
        return abilityCooldownSeconds;
    }

    public List<String> lore() {
        return Arrays.asList(
                "§7" + shortDescription,
                "",
                "§b" + passiveDescription,
                "§d" + activeDescription,
                "",
                "§eКлікни, щоб обрати цей клас"
        );
    }
}
